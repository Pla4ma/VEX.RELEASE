import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  tool: z.string(),
  prompt: z.string().min(1).max(8000),
  system: z.string().optional(),
});

export const runAnalysis = createServerFn({ method: "POST" })
  .inputValidator((d) => Input.parse(d))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) {
      return { ok: false as const, error: "AI not configured: LOVABLE_API_KEY missing." };
    }
    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: data.system ?? `You are Noctra Core, a sharp founder intelligence assistant. Tool: ${data.tool}. Be concise, structured, no fluff. Return short markdown sections.` },
            { role: "user", content: data.prompt },
          ],
        }),
      });
      if (!res.ok) {
        if (res.status === 429) return { ok: false as const, error: "Rate limited. Try again in a moment." };
        if (res.status === 402) return { ok: false as const, error: "Lovable AI credits exhausted." };
        return { ok: false as const, error: `Gateway error ${res.status}` };
      }
      const json = await res.json() as { choices?: { message?: { content?: string } }[] };
      return { ok: true as const, content: json.choices?.[0]?.message?.content ?? "" };
    } catch (e) {
      return { ok: false as const, error: e instanceof Error ? e.message : "Unknown error" };
    }
  });

export const aiHealth = createServerFn({ method: "GET" }).handler(async () => {
  return { configured: Boolean(process.env.LOVABLE_API_KEY) };
});
