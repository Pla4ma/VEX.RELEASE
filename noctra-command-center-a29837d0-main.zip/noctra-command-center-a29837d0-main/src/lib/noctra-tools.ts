import {
  LayoutDashboard, ScanSearch, AlertTriangle, ListChecks, FlaskConical,
  Users, Stethoscope, Rocket, Brain, IdCard, CheckSquare, FileText,
  type LucideIcon,
} from "lucide-react";

export type ToolKey =
  | "dashboard" | "idea" | "reality" | "mvp" | "proof" | "swarm"
  | "doctor" | "launch" | "twin" | "passport" | "tasks" | "reports";

export type Tool = {
  key: ToolKey;
  route: string;
  label: string;
  diegetic: string;
  short: string;
  long: string;
  icon: LucideIcon;
  accent: string;       // primary accent oklch
  accent2: string;      // secondary accent
  group: "Core" | "Validation" | "Build" | "Launch";
};

const cyan = "var(--noctra-cyan)";
const violet = "var(--noctra-violet)";
const magenta = "var(--noctra-magenta)";
const emerald = "var(--noctra-emerald)";
const amber = "var(--noctra-amber)";
const rose = "var(--noctra-rose)";
const gold = "var(--noctra-gold)";

export const TOOLS: Tool[] = [
  { key: "dashboard", route: "/app", label: "Command Center", diegetic: "Command Center", short: "Mission control", long: "Cinematic mission control with next best move and intelligence overview.", icon: LayoutDashboard, accent: cyan, accent2: violet, group: "Core" },
  { key: "reports", route: "/app/reports", label: "Intelligence Archive", diegetic: "Intelligence Archive", short: "Briefings", long: "All intelligence briefings produced across tools.", icon: FileText, accent: "var(--noctra-text-soft)", accent2: violet, group: "Core" },
  { key: "tasks", route: "/app/tasks", label: "Execution Queue", diegetic: "Execution Queue", short: "Sprint board", long: "Operational tasks generated from your validation work.", icon: CheckSquare, accent: emerald, accent2: cyan, group: "Core" },

  { key: "idea", route: "/app/idea", label: "Signal Scanner", diegetic: "Signal Scanner", short: "Idea scanner", long: "Stress test raw ideas against the market signal field.", icon: ScanSearch, accent: violet, accent2: cyan, group: "Validation" },
  { key: "reality", route: "/app/reality", label: "Reality Scanner", diegetic: "Reality Scanner", short: "Risk compiler", long: "Compile assumptions into feasibility, risk, and blind spots.", icon: AlertTriangle, accent: amber, accent2: rose, group: "Validation" },
  { key: "proof", route: "/app/proof", label: "Validation Lab", diegetic: "Validation Lab", short: "Proof engine", long: "Quantify proof signal and design experiments.", icon: FlaskConical, accent: emerald, accent2: gold, group: "Validation" },
  { key: "swarm", route: "/app/swarm", label: "Market Simulation", diegetic: "Market Simulation", short: "Swarm sim", long: "Simulate persona reactions, objections, and excitement.", icon: Users, accent: cyan, accent2: violet, group: "Validation" },

  { key: "mvp", route: "/app/mvp", label: "Execution Blueprint", diegetic: "Execution Blueprint", short: "MVP planner", long: "Compress an idea into a focused, build-ready MVP scope.", icon: ListChecks, accent: cyan, accent2: emerald, group: "Build" },
  { key: "doctor", route: "/app/doctor", label: "Diagnostic Bay", diegetic: "Diagnostic Bay", short: "Project doctor", long: "Diagnose a codebase: health, severity, and repair queue.", icon: Stethoscope, accent: rose, accent2: cyan, group: "Build" },
  { key: "twin", route: "/app/twin", label: "Memory Core", diegetic: "Memory Core", short: "Product twin", long: "Persistent product memory and AI council.", icon: Brain, accent: magenta, accent2: violet, group: "Build" },

  { key: "launch", route: "/app/launch", label: "Launch Control", diegetic: "Launch Control", short: "Launch room", long: "Launch readiness, war games, and telemetry.", icon: Rocket, accent: amber, accent2: cyan, group: "Launch" },
  { key: "passport", route: "/app/passport", label: "Founder Passport", diegetic: "Founder Passport", short: "Passport", long: "Your founder progression and milestone glyphs.", icon: IdCard, accent: gold, accent2: cyan, group: "Launch" },
];

export const TOOL_BY_KEY: Record<ToolKey, Tool> = Object.fromEntries(
  TOOLS.map((t) => [t.key, t])
) as Record<ToolKey, Tool>;

export const TOOL_GROUPS: Tool["group"][] = ["Core", "Validation", "Build", "Launch"];
