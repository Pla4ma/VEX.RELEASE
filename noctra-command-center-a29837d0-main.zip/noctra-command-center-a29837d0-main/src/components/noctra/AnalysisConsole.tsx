import { useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Loader2, Zap } from "lucide-react";
import { runAnalysis } from "@/lib/ai.functions";
import type { ToolKey, Tool } from "@/lib/noctra-tools";
import { TOOL_EXAMPLES } from "@/lib/noctra-journey";
import { NoctraCompanion } from "./NoctraCompanion";
import { IntelligenceBriefing } from "./IntelligenceBriefing";

export function AnalysisConsole({
  tool, placeholder, system, accent = "var(--noctra-cyan)", accent2 = "var(--noctra-violet)",
  preview,
}: {
  tool: Tool;
  placeholder: string;
  system?: string;
  accent?: string;
  accent2?: string;
  preview?: ReactNode; // tool-specific live preview while idle/typing
}) {
  const run = useServerFn(runAnalysis);
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function onRun() {
    if (!prompt.trim() || loading) return;
    setLoading(true); setError(null); setResult(null);
    try {
      const r = await run({ data: { tool: tool.key as ToolKey, prompt, system } });
      if (r.ok) setResult(r.content); else setError(r.error);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally { setLoading(false); }
  }

  const examples = TOOL_EXAMPLES[tool.key as ToolKey] ?? [];
  const state = loading ? "analyzing" : error ? "warning" : result ? "success" : "idle";

  return (
    <div className="grid lg:grid-cols-[1fr_300px] gap-6">
      <div className="space-y-5">
        {/* Command input */}
        <div
          className="holo rounded-2xl p-5 relative overflow-hidden"
          style={{ borderColor: `color-mix(in oklab, ${accent} 35%, transparent)` }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Zap size={12} style={{ color: accent }} />
              <span className="text-[10px] uppercase tracking-[0.28em]" style={{ color: accent }}>
                Founder context
              </span>
            </div>
            <span className="text-[10px] uppercase tracking-[0.22em] text-text-muted">{prompt.length} / 8000</span>
          </div>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value.slice(0, 8000))}
            placeholder={placeholder}
            rows={6}
            className="w-full resize-y rounded-xl bg-black/30 border border-white/5 px-4 py-3 text-sm placeholder:text-text-muted focus:outline-none focus:border-white/15 font-medium"
          />
          {examples.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {examples.map((ex) => (
                <button
                  key={ex}
                  type="button"
                  onClick={() => setPrompt(ex)}
                  className="text-[11px] px-2.5 py-1 rounded-full glass hover:bg-white/[0.06] text-text-soft"
                >
                  {ex.slice(0, 56)}{ex.length > 56 ? "…" : ""}
                </button>
              ))}
            </div>
          )}
          <div className="mt-4 flex items-center justify-between gap-3">
            <div className="text-xs text-text-muted">
              {loading ? "Scanning founder context…" : "Press Run to compile briefing"}
            </div>
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={onRun}
              disabled={loading || !prompt.trim()}
              className="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium disabled:opacity-50"
              style={{
                background: `linear-gradient(135deg, ${accent}, ${accent2})`,
                color: "white",
                boxShadow: `0 14px 40px -14px color-mix(in oklab, ${accent} 70%, transparent)`,
              }}
            >
              {loading ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
              {loading ? "Compiling briefing" : "Run analysis"}
            </motion.button>
          </div>

          {/* idle preview pane */}
          {preview && !loading && !result && !error && (
            <div className="mt-5 rounded-xl border border-white/5 bg-black/20 p-4">
              {preview}
            </div>
          )}

          <AnimatePresence>
            {loading && (
              <motion.div
                initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className="mt-5 rounded-xl border border-white/5 bg-black/30 p-5 relative overflow-hidden"
              >
                <div className="absolute inset-x-0 top-0 h-px animate-scan"
                  style={{ background: `linear-gradient(90deg, transparent, ${accent}, transparent)` }} />
                <div className="space-y-2.5">
                  <div className="h-3 w-1/3 rounded shimmer" />
                  <div className="h-3 w-2/3 rounded shimmer" />
                  <div className="h-3 w-1/2 rounded shimmer" />
                  <div className="h-3 w-3/4 rounded shimmer" />
                </div>
                <div className="mt-3 text-[11px] uppercase tracking-[0.22em] text-text-muted">
                  Noctra Core · analyzing
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Result briefing */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="holo rounded-2xl p-5 text-sm text-rose-300"
              style={{ borderColor: "color-mix(in oklab, var(--noctra-rose) 40%, transparent)" }}
            >
              {error}
            </motion.div>
          )}
          {result && (
            <IntelligenceBriefing
              key="briefing"
              tool={tool}
              raw={result}
              accent={accent}
            />
          )}
        </AnimatePresence>
      </div>

      {/* Companion side */}
      <div className="space-y-3">
        <div className="holo rounded-2xl p-5 flex flex-col items-center text-center"
          style={{ borderColor: `color-mix(in oklab, ${accent} 30%, transparent)` }}>
          <NoctraCompanion state={state as never} size={150} variant="tool" label="Noctra Core" />
          <div className="mt-3 text-xs text-text-muted max-w-[220px]">
            {loading ? "Compiling reality. Holding for signal."
              : error ? "Signal disturbed. Re-feed founder context."
              : result ? "Briefing compiled. Review the intelligence panel."
              : "Awaiting founder context. Drop a sharp prompt."}
          </div>
        </div>
      </div>
    </div>
  );
}
