import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { TOOL_BY_KEY, type ToolKey } from "@/lib/noctra-tools";

export function RelatedTools({ keys, title = "Recommended next" }: { keys: ToolKey[]; title?: string }) {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted mb-3">{title}</div>
      <div className="grid sm:grid-cols-3 gap-3">
        {keys.map((k) => {
          const t = TOOL_BY_KEY[k]; if (!t) return null;
          const Icon = t.icon;
          return (
            <Link key={k} to={t.route}
              className="group glass rounded-xl p-4 flex items-center gap-3 hover:bg-white/[0.04]"
              style={{ borderColor: `color-mix(in oklab, ${t.accent} 25%, transparent)` }}>
              <div className="grid place-items-center h-9 w-9 rounded-lg"
                style={{
                  background: `linear-gradient(135deg, color-mix(in oklab, ${t.accent} 22%, transparent), color-mix(in oklab, ${t.accent2} 14%, transparent))`,
                  border: `1px solid color-mix(in oklab, ${t.accent} 35%, transparent)`,
                }}>
                <Icon size={15} style={{ color: t.accent }} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium truncate">{t.diegetic}</div>
                <div className="text-[11px] text-text-muted truncate">{t.short}</div>
              </div>
              <ArrowRight size={13} className="text-text-muted group-hover:text-foreground" />
            </Link>
          );
        })}
      </div>
    </div>
  );
}
