import { motion, useReducedMotion } from "framer-motion";

export type CompanionState =
  | "idle" | "listening" | "thinking" | "analyzing"
  | "coaching" | "warning" | "success" | "error"
  | "launching" | "scanning" | "celebrating";

export type CompanionVariant = "hero" | "dashboard" | "compact" | "tool";

const STATE_TONE: Record<CompanionState, { primary: string; secondary: string; speed: number; pulse: number }> = {
  idle:       { primary: "var(--noctra-cyan)",    secondary: "var(--noctra-violet)",  speed: 18, pulse: 3.0 },
  listening:  { primary: "var(--noctra-cyan)",    secondary: "var(--noctra-violet)",  speed: 12, pulse: 2.4 },
  thinking:   { primary: "var(--noctra-magenta)", secondary: "var(--noctra-violet)",  speed: 8,  pulse: 1.6 },
  analyzing:  { primary: "var(--noctra-violet)",  secondary: "var(--noctra-cyan)",    speed: 5,  pulse: 1.0 },
  coaching:   { primary: "var(--noctra-cyan)",    secondary: "var(--noctra-emerald)", speed: 14, pulse: 2.4 },
  warning:    { primary: "var(--noctra-amber)",   secondary: "var(--noctra-rose)",    speed: 10, pulse: 1.6 },
  success:    { primary: "var(--noctra-emerald)", secondary: "var(--noctra-gold)",    speed: 22, pulse: 2.6 },
  error:      { primary: "var(--noctra-rose)",    secondary: "var(--noctra-amber)",   speed: 8,  pulse: 1.4 },
  launching:  { primary: "var(--noctra-amber)",   secondary: "var(--noctra-cyan)",    speed: 4,  pulse: 0.8 },
  scanning:   { primary: "var(--noctra-cyan)",    secondary: "var(--noctra-violet)",  speed: 6,  pulse: 1.2 },
  celebrating:{ primary: "var(--noctra-gold)",    secondary: "var(--noctra-magenta)", speed: 16, pulse: 1.8 },
};

export function NoctraCompanion({
  state = "idle",
  size = 200,
  label,
  variant = "dashboard",
  message,
}: {
  state?: CompanionState;
  size?: number;
  label?: string;
  variant?: CompanionVariant;
  message?: string;
}) {
  const reduced = useReducedMotion();
  const tone = STATE_TONE[state];
  const { primary, secondary } = tone;

  // pseudo-3D helmet/core. visor slit + signal eyes.
  return (
    <div className="relative inline-flex flex-col items-center gap-3" style={{ width: size }}>
      <div
        className="relative perspective-1200"
        style={{ width: size, height: size }}
      >
        {/* outer aura */}
        <div className="absolute inset-0 rounded-full blur-2xl opacity-60"
          style={{ background: `radial-gradient(circle, color-mix(in oklab, ${primary} 45%, transparent), transparent 65%)` }} />

        {/* outer rotating ring with tick marks */}
        <motion.svg
          className="absolute inset-0"
          viewBox="0 0 200 200"
          animate={reduced ? {} : { rotate: 360 }}
          transition={{ duration: tone.speed, ease: "linear", repeat: Infinity }}
        >
          <circle cx="100" cy="100" r="96" fill="none"
            stroke={`color-mix(in oklab, ${primary} 50%, transparent)`} strokeWidth="0.6" />
          {Array.from({ length: 36 }).map((_, i) => {
            const a = (i * 10 * Math.PI) / 180;
            const inner = i % 3 === 0 ? 88 : 92;
            return (
              <line key={i}
                x1={100 + Math.cos(a) * inner} y1={100 + Math.sin(a) * inner}
                x2={100 + Math.cos(a) * 96} y2={100 + Math.sin(a) * 96}
                stroke={`color-mix(in oklab, ${primary} 60%, transparent)`} strokeWidth="0.8" />
            );
          })}
        </motion.svg>

        {/* mid dashed ring */}
        <motion.div
          className="absolute rounded-full"
          style={{
            inset: size * 0.12,
            border: `1px dashed color-mix(in oklab, ${secondary} 50%, transparent)`,
          }}
          animate={reduced ? {} : { rotate: -360 }}
          transition={{ duration: tone.speed * 1.4, ease: "linear", repeat: Infinity }}
        />

        {/* helmet/core (pseudo 3d) */}
        <motion.div
          className="absolute"
          style={{
            inset: size * 0.2,
            transformStyle: "preserve-3d",
          }}
          animate={reduced ? {} : { y: [0, -4, 0], rotateX: [4, -4, 4], rotateY: [-3, 3, -3] }}
          transition={{ duration: 6, ease: "easeInOut", repeat: Infinity }}
        >
          {/* helmet body */}
          <div
            className="absolute inset-0 rounded-[40%]"
            style={{
              background: `radial-gradient(120% 100% at 30% 20%, oklch(0.45 0.06 262), oklch(0.16 0.025 262) 70%)`,
              border: `1px solid color-mix(in oklab, ${primary} 45%, transparent)`,
              boxShadow: `inset 0 8px 30px oklch(1 0 0 / 0.08), inset 0 -10px 30px oklch(0 0 0 / 0.5), 0 30px 50px -25px color-mix(in oklab, ${primary} 60%, transparent)`,
            }}
          />
          {/* visor slit */}
          <div
            className="absolute left-[12%] right-[12%] top-[42%] h-[18%] rounded-full overflow-hidden"
            style={{
              background: `linear-gradient(180deg, oklch(0.06 0.02 262), oklch(0.12 0.03 262))`,
              border: `1px solid color-mix(in oklab, ${primary} 60%, transparent)`,
              boxShadow: `inset 0 0 20px color-mix(in oklab, ${primary} 50%, transparent)`,
            }}
          >
            {/* signal eyes */}
            <div className="absolute inset-0 flex items-center justify-around px-[18%]">
              <motion.span
                className="block h-2 w-2 rounded-full animate-blink"
                style={{ background: primary, boxShadow: `0 0 12px ${primary}` }}
                animate={reduced ? {} : { opacity: [0.7, 1, 0.7] }}
                transition={{ duration: tone.pulse, repeat: Infinity, ease: "easeInOut" }}
              />
              <motion.span
                className="block h-2 w-2 rounded-full animate-blink"
                style={{ background: primary, boxShadow: `0 0 12px ${primary}`, animationDelay: "0.2s" }}
                animate={reduced ? {} : { opacity: [0.7, 1, 0.7] }}
                transition={{ duration: tone.pulse, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
              />
            </div>
            {/* visor scan beam */}
            {(state === "analyzing" || state === "scanning") && !reduced && (
              <div
                className="absolute inset-y-0 w-[20%] animate-orbit-fast"
                style={{
                  background: `linear-gradient(90deg, transparent, ${primary}, transparent)`,
                  filter: "blur(2px)",
                  animation: "noctra-scan 1.6s linear infinite",
                }}
              />
            )}
          </div>
          {/* central core glow */}
          <div
            className="absolute left-1/2 top-[78%] h-2 w-2 -translate-x-1/2 rounded-full"
            style={{ background: primary, boxShadow: `0 0 16px ${primary}` }}
          />
        </motion.div>

        {/* orbiting nodes */}
        {[0, 120, 240].map((deg, i) => (
          <motion.div
            key={i}
            className="absolute inset-0"
            animate={reduced ? {} : { rotate: 360 }}
            transition={{ duration: tone.speed * 0.7, ease: "linear", repeat: Infinity, delay: i * 0.3 }}
            style={{ transformOrigin: "50% 50%", rotate: `${deg}deg` }}
          >
            <div
              className="absolute h-1.5 w-1.5 rounded-full"
              style={{
                top: 4, left: "50%",
                background: i % 2 ? secondary : primary,
                boxShadow: `0 0 10px ${i % 2 ? secondary : primary}`,
              }}
            />
          </motion.div>
        ))}

        {/* holographic base */}
        {variant !== "compact" && (
          <div
            className="absolute left-1/2 -translate-x-1/2 rounded-[50%]"
            style={{
              bottom: -size * 0.04,
              width: size * 0.7,
              height: size * 0.06,
              background: `radial-gradient(50% 100% at 50% 0%, color-mix(in oklab, ${primary} 50%, transparent), transparent 70%)`,
              filter: "blur(2px)",
            }}
          />
        )}
      </div>

      {label && (
        <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">{label}</div>
      )}

      {message && variant !== "compact" && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-xl px-3 py-2 text-xs text-text-soft max-w-[260px] text-center"
          style={{ borderColor: `color-mix(in oklab, ${primary} 35%, transparent)` }}
        >
          {message}
        </motion.div>
      )}
    </div>
  );
}

export function CompanionCoach({
  state = "coaching",
  title,
  message,
  cta,
  size = 180,
}: {
  state?: CompanionState; title?: string; message: string;
  cta?: { label: string; onClick?: () => void; href?: string };
  size?: number;
}) {
  const tone = STATE_TONE[state];
  return (
    <div className="relative grid sm:grid-cols-[auto_1fr] gap-5 items-center">
      <NoctraCompanion state={state} size={size} variant="dashboard" />
      <div className="glass rounded-2xl p-4 relative"
        style={{ borderColor: `color-mix(in oklab, ${tone.primary} 35%, transparent)` }}>
        <div className="text-[10px] uppercase tracking-[0.28em]" style={{ color: tone.primary }}>
          Noctra Core · {state}
        </div>
        {title && <div className="mt-1 font-semibold text-foreground">{title}</div>}
        <div className="mt-1 text-sm text-text-soft">{message}</div>
        {cta && (
          <a
            href={cta.href}
            onClick={cta.onClick}
            className="mt-3 inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium text-white"
            style={{ background: `linear-gradient(135deg, ${tone.primary}, ${tone.secondary})` }}
          >
            {cta.label}
          </a>
        )}
      </div>
    </div>
  );
}
