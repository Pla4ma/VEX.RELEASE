import { motion } from "framer-motion";
import { useMemo, useState } from "react";
import { Copy, Check, FileText } from "lucide-react";
import type { Tool } from "@/lib/noctra-tools";
import { ScoreRing } from "./Primitives";
import { stagger, fadeUp } from "@/lib/noctra-motion";

type Section = { heading: string | null; lines: string[] };

function parse(raw: string): Section[] {
  const blocks = raw.replace(/\r/g, "").split(/\n{2,}/);
  const out: Section[] = [];
  let current: Section = { heading: null, lines: [] };
  const flush = () => {
    if (current.heading || current.lines.length) out.push(current);
    current = { heading: null, lines: [] };
  };
  for (const b of blocks) {
    const lines = b.split("\n").filter((l) => l.trim().length);
    if (!lines.length) continue;
    const first = lines[0];
    const m = first.match(/^#{1,4}\s+(.*)$/) || first.match(/^\*\*(.+)\*\*\:?$/);
    if (m) {
      flush();
      current.heading = m[1].trim();
      current.lines = lines.slice(1);
    } else {
      current.lines.push(...lines);
    }
    flush();
  }
  return out.filter((s) => s.heading || s.lines.length);
}

function deriveScore(text: string): { score: number; verdict: string; tone: string } {
  const t = text.toLowerCase();
  let score = 60;
  if (/strong|validated|launch|ship|high signal/.test(t)) score += 20;
  if (/weak|risk|caution|blind|missing|low signal|reject/.test(t)) score -= 18;
  if (/critical|fatal|abort|stop/.test(t)) score -= 25;
  score = Math.max(20, Math.min(95, score));
  const verdict = score >= 78 ? "Strong" : score >= 60 ? "Mixed" : score >= 40 ? "Caution" : "Critical";
  const tone = score >= 78 ? "var(--noctra-emerald)"
    : score >= 60 ? "var(--noctra-cyan)"
    : score >= 40 ? "var(--noctra-amber)" : "var(--noctra-rose)";
  return { score, verdict, tone };
}

function renderLine(line: string, key: number) {
  const bullet = line.match(/^\s*[-*•]\s+(.*)/);
  const number = line.match(/^\s*(\d+)[.)]\s+(.*)/);
  if (bullet) {
    return (
      <li key={key} className="pl-4 relative text-sm text-text-soft">
        <span className="absolute left-0 top-2 h-1.5 w-1.5 rounded-full bg-cyan/80" />
        <span dangerouslySetInnerHTML={{ __html: inline(bullet[1]) }} />
      </li>
    );
  }
  if (number) {
    return (
      <li key={key} className="pl-7 relative text-sm text-text-soft">
        <span className="absolute left-0 top-0.5 text-[10px] uppercase tracking-[0.18em] text-text-muted">{number[1].padStart(2, "0")}</span>
        <span dangerouslySetInnerHTML={{ __html: inline(number[2]) }} />
      </li>
    );
  }
  return (
    <p key={key} className="text-sm text-text-soft leading-relaxed"
      dangerouslySetInnerHTML={{ __html: inline(line) }} />
  );
}

function inline(s: string) {
  return s
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/\*\*(.+?)\*\*/g, '<strong class="text-foreground">$1</strong>')
    .replace(/`([^`]+)`/g, '<code class="px-1.5 py-0.5 rounded bg-white/5 text-cyan text-[12px]">$1</code>');
}

export function IntelligenceBriefing({ tool, raw, accent = "var(--noctra-cyan)" }: {
  tool: Tool; raw: string; accent?: string;
}) {
  const sections = useMemo(() => parse(raw), [raw]);
  const { score, verdict, tone } = useMemo(() => deriveScore(raw), [raw]);
  const [copied, setCopied] = useState(false);

  function copy() {
    navigator.clipboard.writeText(raw).then(() => {
      setCopied(true); setTimeout(() => setCopied(false), 1500);
    });
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
      className="holo rounded-2xl overflow-hidden"
      style={{ borderColor: `color-mix(in oklab, ${tone} 40%, transparent)` }}
    >
      {/* Header */}
      <div className="relative px-5 pt-5 pb-4 border-b border-white/5">
        <div className="absolute inset-x-0 top-0 h-px"
          style={{ background: `linear-gradient(90deg, transparent, ${tone}, transparent)` }} />
        <div className="flex items-start gap-4">
          <div className="grid place-items-center h-12 w-12 rounded-xl"
            style={{
              background: `linear-gradient(135deg, color-mix(in oklab, ${tone} 25%, transparent), color-mix(in oklab, ${accent} 18%, transparent))`,
              border: `1px solid color-mix(in oklab, ${tone} 45%, transparent)`,
            }}>
            <FileText size={18} style={{ color: tone }} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Intelligence briefing</div>
            <div className="mt-0.5 text-lg font-semibold">{tool.diegetic} · {verdict}</div>
            <div className="text-xs text-text-muted">Compiled by Noctra Core · {new Date().toLocaleString()}</div>
          </div>
          <div className="flex items-center gap-3">
            <ScoreRing value={score} size={64} accent={tone} label="Signal" />
            <button
              onClick={copy}
              className="rounded-lg glass p-2 text-text-soft hover:text-foreground"
              aria-label="Copy briefing"
            >
              {copied ? <Check size={14} className="text-emerald" /> : <Copy size={14} />}
            </button>
          </div>
        </div>
      </div>

      {/* Body */}
      <motion.div
        variants={stagger(0.06)} initial="hidden" animate="show"
        className="px-5 py-5 space-y-5"
      >
        {sections.length === 0 ? (
          <p className="text-sm text-text-soft">{raw}</p>
        ) : sections.map((s, i) => (
          <motion.div key={i} variants={fadeUp} className="space-y-2">
            {s.heading && (
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: tone, boxShadow: `0 0 8px ${tone}` }} />
                <h3 className="text-sm uppercase tracking-[0.22em] text-foreground">{s.heading}</h3>
              </div>
            )}
            <div className="space-y-1.5">
              <ul className="space-y-1.5">
                {s.lines.map((l, k) => renderLine(l, k))}
              </ul>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Footer */}
      <div className="px-5 py-3 border-t border-white/5 flex items-center justify-between text-[10px] uppercase tracking-[0.22em] text-text-muted">
        <span>Source · {tool.label}</span>
        <span style={{ color: tone }}>Verdict · {verdict}</span>
      </div>
    </motion.section>
  );
}
