export function NoctraBackground({ variant = "app" }: { variant?: "app" | "hero" }) {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-[0.32]" />
      <div className="absolute inset-0 noise opacity-[0.04] mix-blend-overlay" />

      {/* signal star field */}
      <svg className="absolute inset-0 w-full h-full opacity-50" aria-hidden>
        <defs>
          <radialGradient id="bg-star" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="white" stopOpacity="0.9" />
            <stop offset="100%" stopColor="white" stopOpacity="0" />
          </radialGradient>
        </defs>
        {Array.from({ length: 40 }).map((_, i) => {
          const x = (i * 137) % 100;
          const y = (i * 89) % 100;
          const r = (i % 3) + 0.6;
          return <circle key={i} cx={`${x}%`} cy={`${y}%`} r={r} fill="url(#bg-star)" opacity={0.5 + (i % 5) * 0.1} />;
        })}
      </svg>

      <div
        className="absolute -top-40 -left-40 h-[42rem] w-[42rem] rounded-full blur-3xl opacity-30"
        style={{ background: "radial-gradient(circle, oklch(0.7 0.22 290 / 0.55), transparent 60%)" }}
      />
      <div
        className="absolute -bottom-40 -right-40 h-[42rem] w-[42rem] rounded-full blur-3xl opacity-25"
        style={{ background: "radial-gradient(circle, oklch(0.84 0.16 210 / 0.55), transparent 60%)" }}
      />
      <div
        className="absolute top-1/3 left-1/2 h-[20rem] w-[20rem] -translate-x-1/2 rounded-full blur-3xl opacity-15"
        style={{ background: "radial-gradient(circle, oklch(0.72 0.24 340 / 0.5), transparent 60%)" }}
      />

      {variant === "hero" && (
        <svg className="absolute inset-0 w-full h-full" aria-hidden>
          <g stroke="oklch(0.84 0.16 210 / 0.18)" strokeWidth="0.5" fill="none">
            <path d="M0,400 Q400,300 800,400 T1600,400" className="animate-flow" strokeDasharray="4 8" />
            <path d="M0,500 Q400,420 800,520 T1600,500" className="animate-flow" strokeDasharray="4 8" style={{ animationDelay: "1s" }} />
          </g>
        </svg>
      )}
    </div>
  );
}

export function SignalField({ accent = "var(--noctra-cyan)" }: { accent?: string }) {
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none" aria-hidden>
      <defs>
        <linearGradient id="sf-l" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={accent} stopOpacity="0" />
          <stop offset="50%" stopColor={accent} stopOpacity="0.5" />
          <stop offset="100%" stopColor={accent} stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0.2, 0.4, 0.6, 0.8].map((t, i) => (
        <line key={i} x1="0" y1={`${t * 100}%`} x2="100%" y2={`${t * 100}%`}
          stroke="url(#sf-l)" strokeWidth="0.6" className="animate-flow" strokeDasharray="6 12"
          style={{ animationDelay: `${i * 0.4}s` }} />
      ))}
    </svg>
  );
}
