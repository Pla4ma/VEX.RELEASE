import { Link, useRouterState, Outlet } from "@tanstack/react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronsLeft, ChevronsRight, Search, Bell, Sparkles, Menu } from "lucide-react";
import { TOOLS, TOOL_GROUPS } from "@/lib/noctra-tools";
import { NoctraLogo, NoctraMark } from "./NoctraLogo";
import { NoctraBackground } from "./NoctraBackground";

export function AppShell() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen w-full text-foreground">
      <NoctraBackground />
      <div className="flex">
        {/* Desktop sidebar */}
        <aside
          className={`hidden md:block sticky top-0 h-screen shrink-0 transition-[width] duration-300 ${collapsed ? "w-[76px]" : "w-[256px]"}`}
        >
          <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} pathname={pathname} />
        </aside>

        {/* Mobile drawer */}
        <AnimatePresence>
          {mobileOpen && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onClick={() => setMobileOpen(false)}
                className="md:hidden fixed inset-0 bg-black/60 z-40" />
              <motion.aside
                initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
                transition={{ type: "spring", stiffness: 260, damping: 28 }}
                className="md:hidden fixed top-0 left-0 z-50 h-screen w-[260px]">
                <Sidebar collapsed={false} setCollapsed={() => setMobileOpen(false)} pathname={pathname} onNav={() => setMobileOpen(false)} />
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Main */}
        <div className="flex-1 min-w-0">
          <header className="sticky top-0 z-30 backdrop-blur-md bg-background/40 border-b border-white/5">
            <div className="flex items-center gap-3 px-4 md:px-6 py-3">
              <button
                className="md:hidden glass rounded-lg p-2 text-text-soft"
                aria-label="Open navigation"
                onClick={() => setMobileOpen(true)}
              >
                <Menu size={16} />
              </button>
              <div className="md:hidden flex items-center gap-2">
                <NoctraMark size={22} />
              </div>
              <div className="hidden md:flex items-center gap-2 glass rounded-lg px-3 py-1.5 w-80 text-sm text-text-muted">
                <Search size={14} />
                <span>Search intelligence, tools, briefings…</span>
                <span className="ml-auto text-[10px] tracking-widest opacity-60">⌘K</span>
              </div>
              <div className="ml-auto flex items-center gap-2">
                <Link to="/" className="hidden sm:inline text-xs uppercase tracking-[0.22em] text-text-muted hover:text-foreground">
                  Landing
                </Link>
                <button className="glass rounded-lg p-2 text-text-soft hover:text-foreground" aria-label="Notifications">
                  <Bell size={15} />
                </button>
                <Link to="/app/idea" className="glass rounded-lg px-3 py-2 text-xs uppercase tracking-[0.2em] flex items-center gap-1.5 text-foreground hover:bg-white/[0.06]">
                  <Sparkles size={13} className="text-cyan" />
                  New scan
                </Link>
              </div>
            </div>
          </header>

          <main className="px-4 md:px-6 py-6 md:py-8 max-w-[1400px] mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={pathname}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.35, ease: "easeOut" }}
              >
                <Outlet />
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>
    </div>
  );
}

function Sidebar({ collapsed, setCollapsed, pathname, onNav }: {
  collapsed: boolean; setCollapsed: (b: boolean) => void; pathname: string; onNav?: () => void;
}) {
  return (
    <div className="glass-strong h-full m-3 ml-3 rounded-2xl flex flex-col overflow-hidden">
      <div className="flex items-center justify-between px-4 py-4">
        <Link to="/app" className="flex items-center gap-2.5" onClick={onNav}>
          {collapsed ? <NoctraMark size={26} animated /> : <NoctraLogo />}
        </Link>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="rounded-md p-1.5 text-text-muted hover:text-foreground hover:bg-white/5"
          aria-label="Toggle sidebar"
        >
          {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-2 pb-4 space-y-5">
        {TOOL_GROUPS.map((group) => {
          const items = TOOLS.filter((t) => t.group === group);
          return (
            <div key={group}>
              {!collapsed && (
                <div className="px-3 mb-1.5 text-[10px] uppercase tracking-[0.24em] text-text-muted">
                  {group}
                </div>
              )}
              <ul className="space-y-0.5">
                {items.map((t) => {
                  const active = pathname === t.route || (t.route !== "/app" && pathname.startsWith(t.route));
                  const Icon = t.icon;
                  return (
                    <li key={t.key} className="relative">
                      {active && (
                        <motion.span
                          layoutId="nav-active"
                          className="absolute inset-0 rounded-lg"
                          style={{
                            background: `linear-gradient(90deg, color-mix(in oklab, ${t.accent} 22%, transparent), transparent)`,
                            border: `1px solid color-mix(in oklab, ${t.accent} 35%, transparent)`,
                          }}
                          transition={{ type: "spring", stiffness: 400, damping: 32 }}
                        />
                      )}
                      <Link
                        to={t.route}
                        onClick={onNav}
                        className={`relative z-10 flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                          active ? "text-foreground" : "text-text-soft hover:text-foreground hover:bg-white/[0.03]"
                        }`}
                      >
                        <Icon className="h-4 w-4 shrink-0" style={active ? { color: t.accent } : undefined} />
                        {!collapsed && <span className="truncate">{t.diegetic}</span>}
                        {!collapsed && active && (
                          <span className="ml-auto h-1.5 w-1.5 rounded-full" style={{ background: t.accent, boxShadow: `0 0 10px ${t.accent}` }} />
                        )}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>

      <div className="border-t border-white/5 p-3">
        <div className={`flex items-center gap-2 ${collapsed ? "justify-center" : ""}`}>
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60 animate-ping" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          {!collapsed && <span className="text-[11px] uppercase tracking-[0.2em] text-text-muted">Noctra Core · Online</span>}
        </div>
      </div>
    </div>
  );
}
