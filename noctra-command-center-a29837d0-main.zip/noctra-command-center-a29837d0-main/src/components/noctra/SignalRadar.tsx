import { motion } from "framer-motion";
import { JOURNEY } from "@/lib/noctra-journey";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

// SVG radial constellation showing the founder journey nodes around a central core.
export function SignalRadar({ activeIndex = 2 }: { activeIndex?: number }) {
  const N = JOURNEY.length;
  const R = 110;
  return (
    <div className="relative aspect-square w-full max-w-[420px] mx-auto">
      <svg viewBox="-150 -150 300 300" className="w-full h-full">
        <defs>
          <radialGradient id="rad-core" cx="0" cy="0" r="50">
            <stop offset="0%" stopColor="white" stopOpacity="1" />
            <stop offset="55%" stopColor="oklch(0.84 0.16 210)" stopOpacity="0.7" />
            <stop offset="100%" stopColor="transparent" />
          </radialGradient>
          <linearGradient id="rad-line" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="oklch(0.84 0.16 210)" stopOpacity="0.5" />
            <stop offset="100%" stopColor="oklch(0.7 0.22 290)" stopOpacity="0.5" />
          </linearGradient>
        </defs>

        {/* radar rings */}
        {[40, 70, 100, 130].map((r) => (
          <circle key={r} r={r} cx="0" cy="0" fill="none"
            stroke="oklch(0.6 0.05 260 / 0.12)" strokeWidth="0.6" />
        ))}
        {/* radial spokes */}
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i * 30 * Math.PI) / 180;
          return (
            <line key={i} x1="0" y1="0"
              x2={Math.cos(a) * 130} y2={Math.sin(a) * 130}
              stroke="oklch(0.6 0.05 260 / 0.08)" strokeWidth="0.5" />
          );
        })}

        {/* sweeping beam */}
        <motion.g
          animate={{ rotate: 360 }}
          transition={{ duration: 14, ease: "linear", repeat: Infinity }}
          style={{ transformOrigin: "0 0" }}
        >
          <path d="M0,0 L130,0 A130,130 0 0,0 113,-65 Z" fill="oklch(0.84 0.16 210 / 0.08)" />
        </motion.g>

        {/* connections */}
        {JOURNEY.map((_, i) => {
          const a = (i / N) * Math.PI * 2 - Math.PI / 2;
          return (
            <line key={i}
              x1="0" y1="0"
              x2={Math.cos(a) * R} y2={Math.sin(a) * R}
              stroke="url(#rad-line)" strokeWidth="0.8" strokeDasharray="2 4" />
          );
        })}

        {/* nodes */}
        {JOURNEY.map((n, i) => {
          const t = TOOL_BY_KEY[n.tool];
          const a = (i / N) * Math.PI * 2 - Math.PI / 2;
          const x = Math.cos(a) * R; const y = Math.sin(a) * R;
          const active = i === activeIndex;
          return (
            <g key={n.key}>
              <motion.circle
                cx={x} cy={y} r={active ? 7 : 4}
                fill={t.accent}
                opacity={active ? 1 : 0.7}
                animate={active ? { r: [7, 9, 7] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
                style={{ filter: `drop-shadow(0 0 ${active ? 12 : 4}px ${t.accent})` }}
              />
              <text x={x} y={y + 18} textAnchor="middle"
                style={{ fontSize: 8, letterSpacing: 1.2, textTransform: "uppercase", fill: active ? "white" : "oklch(0.62 0.03 250)" }}>
                {n.label}
              </text>
            </g>
          );
        })}

        {/* core */}
        <circle r="22" cx="0" cy="0" fill="url(#rad-core)" />
        <circle r="3" cx="0" cy="0" fill="white" />
      </svg>
    </div>
  );
}
