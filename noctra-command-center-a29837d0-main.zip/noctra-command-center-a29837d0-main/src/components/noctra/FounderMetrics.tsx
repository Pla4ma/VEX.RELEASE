import { motion } from "framer-motion";
import { ScoreRing } from "./Primitives";

const METRICS = [
  { label: "Signal quality",       value: 78, accent: "var(--noctra-cyan)" },
  { label: "Validation depth",     value: 62, accent: "var(--noctra-emerald)" },
  { label: "Execution momentum",   value: 71, accent: "var(--noctra-violet)" },
  { label: "Launch readiness",     value: 54, accent: "var(--noctra-amber)" },
];

export function FounderMetrics() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {METRICS.map((m, i) => (
        <motion.div
          key={m.label}
          initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className="holo rounded-2xl p-4 flex items-center gap-3"
          style={{ borderColor: `color-mix(in oklab, ${m.accent} 25%, transparent)` }}
        >
          <ScoreRing value={m.value} size={64} accent={m.accent} />
          <div>
            <div className="text-[10px] uppercase tracking-[0.22em] text-text-muted">{m.label}</div>
            <div className="text-xs text-text-soft mt-1">
              {m.value >= 75 ? "Strong" : m.value >= 55 ? "Stable" : m.value >= 35 ? "Rising" : "Thin"}
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
