import { motion } from "framer-motion";
import { JOURNEY } from "@/lib/noctra-journey";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";
import { Link } from "@tanstack/react-router";

export function JourneyRail({ activeIndex = 2 }: { activeIndex?: number }) {
  return (
    <div className="glass rounded-2xl p-5 relative overflow-hidden">
      <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted mb-4">Founder trajectory</div>
      <div className="relative">
        {/* base track */}
        <div className="absolute left-0 right-0 top-5 h-px bg-white/[0.06]" />
        {/* signal line */}
        <motion.div
          initial={{ scaleX: 0 }} animate={{ scaleX: (activeIndex + 1) / JOURNEY.length }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="absolute left-0 right-0 top-5 h-px origin-left"
          style={{ background: "linear-gradient(90deg, var(--noctra-cyan), var(--noctra-violet))", boxShadow: "0 0 12px var(--noctra-cyan)" }}
        />
        <div className="relative grid gap-2" style={{ gridTemplateColumns: `repeat(${JOURNEY.length}, minmax(0,1fr))` }}>
          {JOURNEY.map((n, i) => {
            const t = TOOL_BY_KEY[n.tool];
            const active = i === activeIndex;
            const past = i < activeIndex;
            return (
              <Link key={n.key} to={t.route} className="group flex flex-col items-center text-center">
                <motion.span
                  whileHover={{ scale: 1.1 }}
                  className="relative z-10 grid place-items-center h-10 w-10 rounded-full border"
                  style={{
                    background: active
                      ? `radial-gradient(circle, ${t.accent}, color-mix(in oklab, ${t.accent} 30%, transparent))`
                      : past
                        ? `color-mix(in oklab, ${t.accent} 22%, transparent)`
                        : "oklch(0.18 0.025 262)",
                    borderColor: `color-mix(in oklab, ${t.accent} ${active ? 80 : past ? 50 : 25}%, transparent)`,
                    boxShadow: active ? `0 0 24px ${t.accent}` : undefined,
                  }}
                >
                  <span className="text-[10px] font-semibold"
                    style={{ color: active ? "white" : past ? t.accent : "var(--noctra-text-muted)" }}>
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </motion.span>
                <div className="mt-2 text-[11px] uppercase tracking-[0.2em] text-text-soft group-hover:text-foreground">{n.label}</div>
                <div className="hidden md:block text-[10px] text-text-muted mt-0.5 line-clamp-1">{n.hint}</div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
