import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { NEXT_BEST_MOVES } from "@/lib/noctra-journey";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export function MissionStack() {
  return (
    <div className="space-y-3">
      {NEXT_BEST_MOVES.map((m, i) => {
        const t = TOOL_BY_KEY[m.tool];
        const Icon = t.icon;
        return (
          <motion.div
            key={m.tool}
            initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.06 }}
          >
            <Link to={t.route}
              className="group block holo rounded-2xl p-4 relative overflow-hidden"
              style={{ borderColor: `color-mix(in oklab, ${t.accent} 30%, transparent)` }}>
              <div className="absolute left-0 top-0 bottom-0 w-1"
                style={{ background: `linear-gradient(180deg, ${t.accent}, ${t.accent2})` }} />
              <div className="flex items-center gap-3 pl-2">
                <div
                  className="grid place-items-center h-10 w-10 rounded-xl shrink-0"
                  style={{
                    background: `linear-gradient(135deg, color-mix(in oklab, ${t.accent} 25%, transparent), color-mix(in oklab, ${t.accent2} 16%, transparent))`,
                    border: `1px solid color-mix(in oklab, ${t.accent} 40%, transparent)`,
                  }}>
                  <Icon size={16} style={{ color: t.accent }} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase tracking-[0.24em] text-text-muted">Priority {i + 1}</span>
                    <span className="text-[10px] uppercase tracking-[0.24em]" style={{ color: t.accent }}>· {m.confidence}% signal</span>
                  </div>
                  <div className="text-sm font-semibold mt-0.5">{m.title}</div>
                  <div className="text-xs text-text-muted">{m.reason}</div>
                </div>
                <ArrowRight size={14} className="text-text-muted group-hover:text-foreground" />
              </div>
            </Link>
          </motion.div>
        );
      })}
    </div>
  );
}
