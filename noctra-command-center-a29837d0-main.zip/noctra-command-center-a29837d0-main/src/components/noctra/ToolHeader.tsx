import { type LucideIcon } from "lucide-react";
import { ToolIcon } from "./ToolCard";
import { motion } from "framer-motion";

export function ToolHeader({
  icon, accent, accent2, label, diegetic, description,
}: {
  icon: LucideIcon; accent: string; accent2?: string;
  label: string; diegetic: string; description: string;
}) {
  return (
    <motion.header
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="relative mb-8"
    >
      <div className="flex items-start gap-4">
        <ToolIcon icon={icon} accent={accent} accent2={accent2} size={56} />
        <div className="min-w-0">
          <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">{label}</div>
          <h1 className="mt-1 text-2xl md:text-3xl font-semibold">
            <span className="text-gradient">{diegetic}</span>
          </h1>
          <p className="mt-1.5 max-w-2xl text-sm text-text-soft">{description}</p>
        </div>
      </div>
      <div
        className="mt-5 h-px w-full"
        style={{ background: `linear-gradient(90deg, transparent, color-mix(in oklab, ${accent} 60%, transparent), transparent)` }}
      />
    </motion.header>
  );
}

export function GlassPanel({ className = "", children, accent }: {
  className?: string; children: React.ReactNode; accent?: string;
}) {
  return (
    <div
      className={`glass rounded-2xl p-5 relative overflow-hidden ${className}`}
      style={accent ? { boxShadow: `inset 0 0 0 1px oklch(1 0 0 / 0.03), 0 20px 60px -30px color-mix(in oklab, ${accent} 50%, transparent)` } : undefined}
    >
      {children}
    </div>
  );
}

export function SectionHeader({ kicker, title, action }: {
  kicker?: string; title: string; action?: React.ReactNode;
}) {
  return (
    <div className="mb-3 flex items-end justify-between gap-3">
      <div>
        {kicker && <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">{kicker}</div>}
        <h2 className="text-lg font-semibold">{title}</h2>
      </div>
      {action}
    </div>
  );
}
