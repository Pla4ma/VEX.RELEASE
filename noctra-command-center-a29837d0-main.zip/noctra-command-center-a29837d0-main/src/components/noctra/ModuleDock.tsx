import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { TOOLS } from "@/lib/noctra-tools";

export function ModuleDock() {
  const tools = TOOLS.filter((t) => !["dashboard", "reports", "tasks", "passport"].includes(t.key));
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
      {tools.map((t, i) => {
        const Icon = t.icon;
        return (
          <motion.div
            key={t.key}
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            <Link to={t.route} className="group block h-full">
              <div
                className="holo rounded-2xl p-4 h-full relative overflow-hidden transition-transform group-hover:-translate-y-0.5"
                style={{ borderColor: `color-mix(in oklab, ${t.accent} 28%, transparent)` }}
              >
                <div
                  className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ background: `radial-gradient(400px 160px at 50% 0%, color-mix(in oklab, ${t.accent} 22%, transparent), transparent 60%)` }}
                />
                <div className="flex items-center gap-3">
                  <div
                    className="grid place-items-center h-11 w-11 rounded-xl relative"
                    style={{
                      background: `linear-gradient(135deg, color-mix(in oklab, ${t.accent} 25%, transparent), color-mix(in oklab, ${t.accent2} 16%, transparent))`,
                      border: `1px solid color-mix(in oklab, ${t.accent} 40%, transparent)`,
                      boxShadow: `0 0 24px color-mix(in oklab, ${t.accent} 25%, transparent)`,
                    }}
                  >
                    <Icon size={17} style={{ color: t.accent }} />
                    <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full"
                      style={{ background: t.accent2, boxShadow: `0 0 8px ${t.accent2}` }} />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold truncate">{t.diegetic}</div>
                    <div className="text-[10px] uppercase tracking-[0.22em] text-text-muted">{t.group}</div>
                  </div>
                </div>
                <div className="mt-3 text-xs text-text-soft line-clamp-2">{t.long}</div>
                <div className="mt-3 flex items-center justify-between text-[10px] uppercase tracking-[0.2em] text-text-muted">
                  <span>Enter module</span>
                  <span style={{ color: t.accent }}>—›</span>
                </div>
              </div>
            </Link>
          </motion.div>
        );
      })}
    </div>
  );
}
