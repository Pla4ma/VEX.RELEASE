import { ToolHeader } from "./ToolHeader";
import { AnalysisConsole } from "./AnalysisConsole";
import type { Tool } from "@/lib/noctra-tools";
import type { ReactNode } from "react";

export function ToolPageShell({
  tool, placeholder, system, kicker, hero, preview, related,
}: {
  tool: Tool; placeholder: string; system?: string;
  kicker?: ReactNode; hero?: ReactNode; preview?: ReactNode; related?: ReactNode;
}) {
  return (
    <div className="space-y-6">
      <ToolHeader
        icon={tool.icon} accent={tool.accent} accent2={tool.accent2}
        label={tool.label} diegetic={tool.diegetic} description={tool.long}
      />
      {hero}
      <AnalysisConsole
        tool={tool} placeholder={placeholder} system={system}
        accent={tool.accent} accent2={tool.accent2} preview={preview}
      />
      {related}
    </div>
  );
}

// Backwards compat: old import name.
export function ToolWorkbench({ tool, placeholder, system }: { tool: Tool; placeholder: string; system?: string }) {
  return <ToolPageShell tool={tool} placeholder={placeholder} system={system} />;
}
