import { motion, useMotionValue, useSpring, useTransform, useReducedMotion } from "framer-motion";
import { useRef, type ReactNode, type CSSProperties } from "react";

export function SpatialCard({
  children, className = "", accent, intensity = 8,
}: { children: ReactNode; className?: string; accent?: string; intensity?: number }) {
  const reduced = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rx = useSpring(useTransform(my, [-1, 1], [intensity, -intensity]), { stiffness: 200, damping: 20 });
  const ry = useSpring(useTransform(mx, [-1, 1], [-intensity, intensity]), { stiffness: 200, damping: 20 });
  const gx = useTransform(mx, [-1, 1], ["0%", "100%"]);
  const gy = useTransform(my, [-1, 1], ["0%", "100%"]);

  function onMove(e: React.MouseEvent) {
    if (!ref.current || reduced) return;
    const r = ref.current.getBoundingClientRect();
    mx.set((e.clientX - r.left) / r.width * 2 - 1);
    my.set((e.clientY - r.top) / r.height * 2 - 1);
  }
  function onLeave() { mx.set(0); my.set(0); }

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      style={{
        rotateX: reduced ? 0 : rx,
        rotateY: reduced ? 0 : ry,
        transformStyle: "preserve-3d",
        boxShadow: accent ? `0 30px 80px -40px color-mix(in oklab, ${accent} 60%, transparent)` : undefined,
      }}
      className={`glass rounded-2xl p-5 relative overflow-hidden ${className}`}
    >
      <motion.div
        className="pointer-events-none absolute inset-0 opacity-0 hover:opacity-100 transition-opacity"
        style={{
          background: useTransform([gx, gy], ([x, y]) =>
            `radial-gradient(400px 240px at ${x} ${y}, color-mix(in oklab, ${accent ?? "var(--noctra-cyan)"} 22%, transparent), transparent 60%)`),
        }}
      />
      <div style={{ transform: "translateZ(20px)" }}>{children}</div>
    </motion.div>
  );
}

export function HoloPanel({
  children, className = "", accent = "var(--noctra-cyan)", style,
}: { children: ReactNode; className?: string; accent?: string; style?: CSSProperties }) {
  return (
    <div className={`holo rounded-2xl p-5 relative overflow-hidden ${className}`}
      style={{ ...style, borderColor: `color-mix(in oklab, ${accent} 35%, transparent)` }}>
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px"
        style={{ background: `linear-gradient(90deg, transparent, color-mix(in oklab, ${accent} 60%, transparent), transparent)` }} />
      {children}
    </div>
  );
}

export function CommandSurface({
  children, className = "", accent = "var(--noctra-cyan)", accent2 = "var(--noctra-violet)",
}: { children: ReactNode; className?: string; accent?: string; accent2?: string }) {
  return (
    <section className={`relative overflow-hidden rounded-3xl glass-strong p-6 md:p-8 ${className}`}>
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-70"
        style={{
          background: `radial-gradient(700px 260px at 90% -20%, color-mix(in oklab, ${accent2} 35%, transparent), transparent 60%), radial-gradient(700px 260px at -10% 120%, color-mix(in oklab, ${accent} 30%, transparent), transparent 60%)`,
        }} />
      <div className="pointer-events-none absolute inset-0 grid-bg-fine opacity-30" />
      {children}
    </section>
  );
}
