import { motion } from "framer-motion";
import { type LucideIcon } from "lucide-react";
import { Link } from "@tanstack/react-router";

export function ToolIcon({ icon: Icon, accent, accent2, size = 44 }: {
  icon: LucideIcon; accent: string; accent2?: string; size?: number;
}) {
  return (
    <div
      className="relative grid place-items-center rounded-xl"
      style={{
        width: size, height: size,
        background: `linear-gradient(135deg, color-mix(in oklab, ${accent} 22%, transparent), color-mix(in oklab, ${accent2 ?? accent} 14%, transparent))`,
        border: `1px solid color-mix(in oklab, ${accent} 35%, transparent)`,
        boxShadow: `inset 0 0 0 1px oklch(1 0 0 / 0.04), 0 0 24px color-mix(in oklab, ${accent} 18%, transparent)`,
      }}
    >
      <Icon className="h-5 w-5" style={{ color: accent }} />
    </div>
  );
}

export function ToolCard({
  to, icon, label, description, accent, accent2,
}: {
  to: string; icon: LucideIcon; label: string; description: string; accent: string; accent2?: string;
}) {
  return (
    <Link to={to} className="group block">
      <motion.div
        whileHover={{ y: -3 }}
        transition={{ type: "spring", stiffness: 300, damping: 24 }}
        className="glass relative overflow-hidden rounded-2xl p-5 h-full"
        style={{ boxShadow: "0 1px 0 oklch(1 0 0 / 0.04) inset" }}
      >
        <div
          className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          style={{
            background: `radial-gradient(600px 200px at 50% -20%, color-mix(in oklab, ${accent} 30%, transparent), transparent 60%)`,
          }}
        />
        <div className="flex items-start gap-3">
          <ToolIcon icon={icon} accent={accent} accent2={accent2} />
          <div className="min-w-0">
            <div className="text-sm font-medium text-foreground">{label}</div>
            <div className="text-xs text-text-muted line-clamp-2 mt-0.5">{description}</div>
          </div>
        </div>
        <div className="mt-4 h-px w-full" style={{ background: `linear-gradient(90deg, transparent, color-mix(in oklab, ${accent} 50%, transparent), transparent)` }} />
        <div className="mt-3 flex items-center justify-between text-[10px] uppercase tracking-[0.18em] text-text-muted">
          <span>Open module</span>
          <span style={{ color: accent }}>—›</span>
        </div>
      </motion.div>
    </Link>
  );
}
