import { motion, useMotionValue, animate } from "framer-motion";
import { useEffect } from "react";

export function AnimatedNumber({ value, duration = 1.2, format }: {
  value: number; duration?: number; format?: (n: number) => string;
}) {
  const mv = useMotionValue(0);
  useEffect(() => {
    const controls = animate(mv, value, { duration, ease: "easeOut" });
    return controls.stop;
  }, [value, duration, mv]);
  return (
    <motion.span>
      {/* eslint-disable-next-line react-hooks/rules-of-hooks */}
      {useMotionRender(mv, format)}
    </motion.span>
  );
}

function useMotionRender(mv: ReturnType<typeof useMotionValue<number>>, format?: (n: number) => string) {
  // returns a node that updates without re-render
  const ref = (node: HTMLSpanElement | null) => {
    if (!node) return;
    const unsub = mv.on("change", (v) => {
      node.textContent = format ? format(v) : String(Math.round(v));
    });
    node.textContent = format ? format(mv.get()) : String(Math.round(mv.get()));
    return unsub;
  };
  return <span ref={ref} />;
}

export function ScoreRing({ value, size = 96, accent = "var(--noctra-cyan)", label }: {
  value: number; size?: number; accent?: string; label?: string;
}) {
  const r = size / 2 - 8;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, value));
  const dash = (pct / 100) * c;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="oklch(1 0 0 / 0.08)" strokeWidth="6" fill="none" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r}
          stroke={accent} strokeWidth="6" fill="none" strokeLinecap="round"
          initial={{ strokeDasharray: `0 ${c}` }}
          animate={{ strokeDasharray: `${dash} ${c}` }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          style={{ filter: `drop-shadow(0 0 6px ${accent})` }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <div className="text-xl font-semibold">
            <AnimatedNumber value={pct} />
          </div>
          {label && <div className="text-[9px] uppercase tracking-[0.22em] text-text-muted">{label}</div>}
        </div>
      </div>
    </div>
  );
}

export function MetricPanel({ label, value, accent = "var(--noctra-cyan)", suffix }: {
  label: string; value: number; accent?: string; suffix?: string;
}) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-[10px] uppercase tracking-[0.22em] text-text-muted">{label}</div>
      <div className="mt-2 flex items-baseline gap-1">
        <span className="text-2xl font-semibold" style={{ color: accent }}>
          <AnimatedNumber value={value} />
        </span>
        {suffix && <span className="text-xs text-text-muted">{suffix}</span>}
      </div>
      <div className="mt-3 h-1 rounded-full bg-white/5 overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(100, value)}%` }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="h-full rounded-full"
          style={{ background: `linear-gradient(90deg, ${accent}, transparent)` }}
        />
      </div>
    </div>
  );
}
