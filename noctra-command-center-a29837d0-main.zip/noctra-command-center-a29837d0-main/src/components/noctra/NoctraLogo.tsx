import { motion } from "framer-motion";

export function NoctraMark({ size = 32, className = "", animated = false }: { size?: number; className?: string; animated?: boolean }) {
  const id = `nx-${size}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className={className} aria-hidden>
      <defs>
        <linearGradient id={`${id}-g`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="oklch(0.84 0.16 210)" />
          <stop offset="55%" stopColor="oklch(0.7 0.22 290)" />
          <stop offset="100%" stopColor="oklch(0.72 0.24 340)" />
        </linearGradient>
        <radialGradient id={`${id}-c`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="white" stopOpacity="1" />
          <stop offset="55%" stopColor="oklch(0.84 0.16 210)" stopOpacity="0.85" />
          <stop offset="100%" stopColor="transparent" />
        </radialGradient>
        <linearGradient id={`${id}-n`} x1="0" y1="1" x2="1" y2="0">
          <stop offset="0%" stopColor="oklch(0.84 0.16 210)" />
          <stop offset="100%" stopColor="oklch(0.72 0.24 340)" />
        </linearGradient>
      </defs>

      {/* outer hex orbital frame */}
      <g opacity="0.55">
        <polygon points="32,4 56,18 56,46 32,60 8,46 8,18"
          fill="none" stroke={`url(#${id}-g)`} strokeWidth="1" />
      </g>

      {/* signal arcs */}
      <g fill="none" stroke={`url(#${id}-g)`} strokeLinecap="round">
        <path d="M14 32 A18 18 0 0 1 50 32" strokeWidth="1.2" opacity="0.6" />
        <path d="M14 32 A18 18 0 0 0 50 32" strokeWidth="1.2" opacity="0.35" />
      </g>

      {/* angular N implied through diagonal beam */}
      <g className={animated ? "animate-orbit-slow" : ""} style={{ transformOrigin: "32px 32px" }}>
        <path d="M18 44 L18 22 L46 44 L46 22" fill="none" stroke={`url(#${id}-n)`} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </g>

      {/* node points */}
      <circle cx="18" cy="22" r="1.6" fill="oklch(0.84 0.16 210)" />
      <circle cx="46" cy="22" r="1.6" fill="oklch(0.72 0.24 340)" />
      <circle cx="18" cy="44" r="1.6" fill="oklch(0.7 0.22 290)" />
      <circle cx="46" cy="44" r="1.6" fill="oklch(0.84 0.16 210)" />

      {/* inner core */}
      <circle cx="32" cy="32" r="6" fill={`url(#${id}-c)`} />
      <circle cx="32" cy="32" r="2" fill="white" opacity="0.95" />
    </svg>
  );
}

export function NoctraWordmark({ className = "" }: { className?: string }) {
  return (
    <span className={`font-semibold tracking-[0.22em] text-[0.95rem] ${className}`}>
      <span className="text-foreground">NOC</span>
      <span className="text-gradient">TRA</span>
    </span>
  );
}

export function NoctraLogo({ collapsed = false }: { collapsed?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <motion.div
        initial={{ rotate: -10, opacity: 0 }}
        animate={{ rotate: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative"
      >
        <NoctraMark size={28} animated />
        <span className="absolute inset-0 rounded-full blur-md opacity-50 ring-glow-cyan pointer-events-none" />
      </motion.div>
      {!collapsed && <NoctraWordmark />}
    </div>
  );
}

export function NoctraSeal({ size = 220, accent = "var(--noctra-cyan)", accent2 = "var(--noctra-violet)" }: { size?: number; accent?: string; accent2?: string }) {
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <div className="absolute inset-0 rounded-full"
        style={{ background: `radial-gradient(circle at 50% 50%, color-mix(in oklab, ${accent} 22%, transparent), transparent 65%)` }} />
      <div className="absolute inset-3 rounded-full border animate-orbit-slow"
        style={{ borderColor: `color-mix(in oklab, ${accent} 50%, transparent)` }} />
      <div className="absolute inset-8 rounded-full border border-dashed animate-orbit-rev"
        style={{ borderColor: `color-mix(in oklab, ${accent2} 50%, transparent)` }} />
      <div className="absolute inset-0 grid place-items-center">
        <NoctraMark size={size * 0.5} animated />
      </div>
    </div>
  );
}

export function NoctraLoader({ size = 64 }: { size?: number }) {
  return (
    <div className="relative inline-flex" style={{ width: size, height: size }}>
      <div className="absolute inset-0 rounded-full border-2 border-cyan/20" />
      <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-cyan animate-orbit" />
      <div className="absolute inset-2 rounded-full border border-violet/40 animate-orbit-rev" />
      <div className="absolute inset-0 grid place-items-center">
        <NoctraMark size={size * 0.45} />
      </div>
    </div>
  );
}
