import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkbench } from "@/components/noctra/ToolWorkbench";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export const Route = createFileRoute("/app/proof")({
  head: () => ({ meta: [{ title: "Validation Lab — Noctra" }] }),
  component: () => (
    <ToolWorkbench
      tool={TOOL_BY_KEY.proof}
      placeholder={`Describe what you've shipped/tested. Noctra scores proof.`}
      system={`You are a validation analyst. Output: Proof score (1-100), signal quality, 3 next experiments.`}
    />
  ),
});
