import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkbench } from "@/components/noctra/ToolWorkbench";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export const Route = createFileRoute("/app/twin")({
  head: () => ({ meta: [{ title: "Memory Core — Noctra" }] }),
  component: () => (
    <ToolWorkbench
      tool={TOOL_BY_KEY.twin}
      placeholder={`Talk to your product twin. Noctra preserves and reasons over memory.`}
      system={`Act as the product's memory core. Output: synthesized recall, contradictions detected, next strategic move.`}
    />
  ),
});
