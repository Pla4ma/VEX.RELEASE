import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkbench } from "@/components/noctra/ToolWorkbench";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export const Route = createFileRoute("/app/idea")({
  head: () => ({ meta: [{ title: "Signal Scanner — Noctra" }] }),
  component: () => (
    <ToolWorkbench
      tool={TOOL_BY_KEY.idea}
      placeholder={`Drop your raw idea. Noctra will stress-test signal vs noise.`}
      system={`Run as a sharp founder analyst. Output: Signal verdict, top 3 strengths, top 3 risks, sharpest experiment.`}
    />
  ),
});
