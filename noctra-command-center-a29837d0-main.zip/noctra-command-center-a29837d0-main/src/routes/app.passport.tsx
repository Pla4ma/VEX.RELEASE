import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Compass, ScanSearch, FlaskConical, Rocket, ShieldCheck, Brain, Trophy, Lock } from "lucide-react";
import { ToolHeader } from "@/components/noctra/ToolHeader";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";
import { ScoreRing } from "@/components/noctra/Primitives";
import { NoctraCompanion } from "@/components/noctra/NoctraCompanion";

export const Route = createFileRoute("/app/passport")({
  head: () => ({ meta: [{ title: "Founder Passport — Noctra" }] }),
  component: PassportPage,
});

const STAMPS = [
  { i: ScanSearch,   label: "First Signal Scan",   earned: true,  desc: "Stress-tested an idea" },
  { i: ShieldCheck,  label: "Reality Compiled",    earned: true,  desc: "Surfaced top assumptions" },
  { i: FlaskConical, label: "Proof Cycle Started", earned: true,  desc: "Validated outbound wedge" },
  { i: Compass,      label: "MVP Compressed",      earned: false, desc: "Scope locked in 6 weeks" },
  { i: Brain,        label: "Memory Core Seeded",  earned: true,  desc: "Product DNA archived" },
  { i: Rocket,       label: "Launch Gate Opened",  earned: false, desc: "Telemetry & gates ready" },
  { i: Trophy,       label: "First Revenue",       earned: false, desc: "Reality has paid you" },
];

function PassportPage() {
  const tool = TOOL_BY_KEY.passport;
  const earned = STAMPS.filter((s) => s.earned).length;
  const trajectory = Math.round((earned / STAMPS.length) * 100);

  return (
    <div className="space-y-6">
      <ToolHeader icon={tool.icon} accent={tool.accent} accent2={tool.accent2}
        label={tool.label} diegetic={tool.diegetic} description="Your founder progression and milestone glyphs." />

      <section className="holo rounded-3xl p-6 md:p-8 grid lg:grid-cols-[1fr_auto] gap-6 items-center"
        style={{ borderColor: `color-mix(in oklab, ${tool.accent} 35%, transparent)` }}>
        <div>
          <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Founder rank</div>
          <h2 className="mt-1 text-3xl md:text-4xl font-semibold">
            <span className="text-gradient">Operator · Tier II</span>
          </h2>
          <p className="mt-2 text-text-soft max-w-xl">{earned} of {STAMPS.length} milestone glyphs unlocked. Three remain to reach launch tier.</p>
          <div className="mt-4 h-2 rounded-full bg-white/5 overflow-hidden max-w-md">
            <motion.div initial={{ width: 0 }} animate={{ width: `${trajectory}%` }} transition={{ duration: 1.2 }}
              className="h-full" style={{ background: `linear-gradient(90deg, ${tool.accent}, ${tool.accent2})`, boxShadow: `0 0 12px ${tool.accent}` }} />
          </div>
        </div>
        <div className="flex items-center gap-4">
          <ScoreRing value={trajectory} size={140} accent={tool.accent} label="Trajectory" />
          <NoctraCompanion size={120} state="celebrating" variant="compact" />
        </div>
      </section>

      <section>
        <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted mb-3">Achievement vault</div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {STAMPS.map((s, i) => (
            <motion.div key={s.label}
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className={`holo rounded-2xl p-5 relative overflow-hidden ${s.earned ? "" : "opacity-60"}`}
              style={{ borderColor: s.earned ? `color-mix(in oklab, ${tool.accent} 45%, transparent)` : "var(--noctra-border)" }}>
              {s.earned && (
                <div className="absolute -top-10 -right-10 h-24 w-24 rounded-full blur-2xl"
                  style={{ background: `radial-gradient(circle, ${tool.accent}, transparent 70%)`, opacity: 0.4 }} />
              )}
              <div className="flex items-start gap-3">
                <div className="grid place-items-center h-12 w-12 rounded-xl relative"
                  style={{
                    background: s.earned
                      ? `linear-gradient(135deg, color-mix(in oklab, ${tool.accent} 30%, transparent), color-mix(in oklab, ${tool.accent2} 18%, transparent))`
                      : "oklch(0.18 0.025 262)",
                    border: `1px solid color-mix(in oklab, ${tool.accent} ${s.earned ? 50 : 18}%, transparent)`,
                    boxShadow: s.earned ? `0 0 24px color-mix(in oklab, ${tool.accent} 30%, transparent)` : "none",
                  }}>
                  {s.earned ? <s.i size={18} style={{ color: tool.accent }} /> : <Lock size={16} className="text-text-muted" />}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold">{s.label}</div>
                  <div className="text-xs text-text-muted mt-0.5">{s.desc}</div>
                  <div className="mt-2 text-[10px] uppercase tracking-[0.22em]"
                    style={{ color: s.earned ? tool.accent : "var(--noctra-text-muted)" }}>
                    {s.earned ? "Unlocked" : "Locked"}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
