import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, FileText, Sparkles } from "lucide-react";
import { CommandSurface } from "@/components/noctra/Surfaces";
import { NoctraCompanion } from "@/components/noctra/NoctraCompanion";
import { JourneyRail } from "@/components/noctra/JourneyRail";
import { SignalRadar } from "@/components/noctra/SignalRadar";
import { MissionStack } from "@/components/noctra/MissionStack";
import { FounderMetrics } from "@/components/noctra/FounderMetrics";
import { ModuleDock } from "@/components/noctra/ModuleDock";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";
import { NEXT_BEST_MOVES } from "@/lib/noctra-journey";
import { stagger, fadeUp } from "@/lib/noctra-motion";

export const Route = createFileRoute("/app/")({
  head: () => ({ meta: [{ title: "Command Center — Noctra" }] }),
  component: Dashboard,
});

function Dashboard() {
  const next = TOOL_BY_KEY[NEXT_BEST_MOVES[0].tool];

  return (
    <motion.div
      variants={stagger(0.08)} initial="hidden" animate="show"
      className="space-y-8"
    >
      {/* HERO COMMAND SURFACE */}
      <motion.div variants={fadeUp}>
        <CommandSurface accent="var(--noctra-cyan)" accent2="var(--noctra-violet)">
          <div className="grid lg:grid-cols-[1.1fr_1fr] gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 glass rounded-full px-3 py-1 text-[10px] uppercase tracking-[0.28em] text-text-soft">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Noctra Core · scanning
              </div>
              <h1 className="mt-5 text-3xl md:text-5xl font-semibold leading-[1.05]">
                Welcome back, founder.<br />
                <span className="text-gradient">Signal is strong tonight.</span>
              </h1>
              <p className="mt-4 max-w-xl text-text-soft">
                I've compiled an updated read on your trajectory. Validation depth is rising;
                proof layer is thin. Open the recommended module below.
              </p>

              <motion.div
                initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                className="mt-6 holo rounded-2xl p-5 flex items-center gap-4 relative overflow-hidden"
                style={{ borderColor: `color-mix(in oklab, ${next.accent} 35%, transparent)` }}
              >
                <div className="absolute inset-y-0 left-0 w-1"
                  style={{ background: `linear-gradient(180deg, ${next.accent}, ${next.accent2})` }} />
                <div className="grid place-items-center rounded-xl h-12 w-12 ml-2"
                  style={{ background: `color-mix(in oklab, ${next.accent} 22%, transparent)`, border: `1px solid color-mix(in oklab, ${next.accent} 45%, transparent)` }}>
                  <next.icon size={20} style={{ color: next.accent }} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[10px] uppercase tracking-[0.24em] text-text-muted">Next best move</div>
                  <div className="font-semibold mt-0.5">{NEXT_BEST_MOVES[0].title}</div>
                  <div className="text-xs text-text-muted mt-0.5">{NEXT_BEST_MOVES[0].reason}</div>
                </div>
                <Link to={next.route} className="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium text-white"
                  style={{ background: `linear-gradient(135deg, ${next.accent}, ${next.accent2})`, boxShadow: `0 14px 40px -14px color-mix(in oklab, ${next.accent} 70%, transparent)` }}>
                  Begin <ArrowRight size={14} />
                </Link>
              </motion.div>

              <div className="mt-4 flex flex-wrap items-center gap-3">
                <Link to="/app/reports" className="glass rounded-lg px-3 py-2 text-xs uppercase tracking-[0.2em] text-text-soft hover:text-foreground inline-flex items-center gap-2">
                  <FileText size={12} /> Open intelligence archive
                </Link>
                <Link to="/app/tasks" className="glass rounded-lg px-3 py-2 text-xs uppercase tracking-[0.2em] text-text-soft hover:text-foreground inline-flex items-center gap-2">
                  <Sparkles size={12} /> Execution queue
                </Link>
              </div>
            </div>

            <div className="hidden lg:flex flex-col items-center gap-4">
              <NoctraCompanion size={300} state="coaching" variant="hero" label="Noctra Core" />
              <div className="text-xs text-text-muted text-center max-w-[280px]">
                "Your fastest path to signal goes through the Validation Lab. Run it after the next idea scan."
              </div>
            </div>
          </div>
        </CommandSurface>
      </motion.div>

      {/* JOURNEY */}
      <motion.div variants={fadeUp}>
        <JourneyRail activeIndex={2} />
      </motion.div>

      {/* RADAR + MISSIONS */}
      <motion.div variants={fadeUp} className="grid lg:grid-cols-[1.1fr_1fr] gap-6">
        <div className="holo rounded-2xl p-5 relative overflow-hidden">
          <div className="flex items-end justify-between mb-2">
            <div>
              <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">System map</div>
              <h3 className="text-lg font-semibold">Signal radar</h3>
            </div>
            <div className="text-[10px] uppercase tracking-[0.22em] text-text-muted">Live</div>
          </div>
          <SignalRadar activeIndex={2} />
        </div>
        <div>
          <div className="flex items-end justify-between mb-3">
            <div>
              <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Mission stack</div>
              <h3 className="text-lg font-semibold">Recommended moves</h3>
            </div>
          </div>
          <MissionStack />
        </div>
      </motion.div>

      {/* METRICS */}
      <motion.div variants={fadeUp}>
        <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted mb-3">Founder metrics</div>
        <FounderMetrics />
      </motion.div>

      {/* MODULE DOCK */}
      <motion.div variants={fadeUp}>
        <div className="flex items-end justify-between mb-3">
          <div>
            <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Module dock</div>
            <h3 className="text-lg font-semibold">Open an intelligence module</h3>
          </div>
        </div>
        <ModuleDock />
      </motion.div>

      {/* INTELLIGENCE FEED */}
      <motion.div variants={fadeUp} className="grid lg:grid-cols-[1.4fr_1fr] gap-6">
        <div className="holo rounded-2xl p-5">
          <div className="flex items-end justify-between mb-3">
            <div>
              <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Recent briefings</div>
              <h3 className="text-lg font-semibold">Intelligence feed</h3>
            </div>
            <Link to="/app/reports" className="text-xs uppercase tracking-[0.22em] text-text-muted hover:text-foreground inline-flex items-center gap-1">
              Open archive <ArrowRight size={12} />
            </Link>
          </div>
          <ul className="space-y-2">
            {[
              { t: "Signal Scan: AI for indie devs", v: "Strong",    a: "var(--noctra-emerald)" },
              { t: "Reality Scan: market timing window", v: "Caution", a: "var(--noctra-amber)" },
              { t: "Validation: cold outbound v3", v: "Validated",   a: "var(--noctra-cyan)" },
              { t: "Diagnostic: dashboard render path", v: "Stable",  a: "var(--noctra-violet)" },
            ].map((b) => (
              <li key={b.t} className="flex items-center justify-between glass rounded-xl px-3 py-2">
                <div className="flex items-center gap-3 min-w-0">
                  <FileText size={14} className="text-text-muted" />
                  <span className="text-sm truncate">{b.t}</span>
                </div>
                <span className="text-[10px] uppercase tracking-[0.22em] px-2 py-0.5 rounded-full"
                  style={{ background: `color-mix(in oklab, ${b.a} 18%, transparent)`, color: b.a }}>{b.v}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="holo rounded-2xl p-5">
          <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Launch readiness</div>
          <h3 className="text-lg font-semibold">Gate progress</h3>
          <ul className="mt-3 space-y-3">
            {[
              { g: "Signal locked", v: 82, a: "var(--noctra-cyan)" },
              { g: "Reality compiled", v: 70, a: "var(--noctra-violet)" },
              { g: "Proof gathered", v: 48, a: "var(--noctra-emerald)" },
              { g: "Launch sequence", v: 22, a: "var(--noctra-amber)" },
            ].map((g) => (
              <li key={g.g}>
                <div className="flex justify-between text-xs">
                  <span className="text-text-soft">{g.g}</span>
                  <span style={{ color: g.a }}>{g.v}%</span>
                </div>
                <div className="mt-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: `${g.v}%` }} transition={{ duration: 1.2, ease: "easeOut" }}
                    className="h-full rounded-full"
                    style={{ background: `linear-gradient(90deg, ${g.a}, transparent)`, boxShadow: `0 0 8px ${g.a}` }} />
                </div>
              </li>
            ))}
          </ul>
        </div>
      </motion.div>
    </motion.div>
  );
}
