import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkbench } from "@/components/noctra/ToolWorkbench";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export const Route = createFileRoute("/app/mvp")({
  head: () => ({ meta: [{ title: "Execution Blueprint — Noctra" }] }),
  component: () => (
    <ToolWorkbench
      tool={TOOL_BY_KEY.mvp}
      placeholder={`Describe the product. Noctra returns a ruthless MVP scope.`}
      system={`You are a focused product strategist. Output: MVP scope, what to cut, week-by-week build path (4 weeks).`}
    />
  ),
});
