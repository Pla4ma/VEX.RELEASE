import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkbench } from "@/components/noctra/ToolWorkbench";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export const Route = createFileRoute("/app/launch")({
  head: () => ({ meta: [{ title: "Launch Control — Noctra" }] }),
  component: () => (
    <ToolWorkbench
      tool={TOOL_BY_KEY.launch}
      placeholder={`Describe your launch context. Noctra returns readiness telemetry.`}
      system={`Act as launch director. Output: Readiness gates (each pass/fail), risk scenarios, war-game questions.`}
    />
  ),
});
