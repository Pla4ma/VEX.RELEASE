import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center">
        <div className="text-[10px] uppercase tracking-[0.32em] text-text-muted">Signal lost</div>
        <h1 className="mt-2 text-7xl font-semibold text-gradient">404</h1>
        <p className="mt-3 text-sm text-text-soft">No briefing exists at this coordinate.</p>
        <Link to="/" className="mt-6 inline-flex items-center justify-center rounded-md glass px-4 py-2 text-sm">
          Return to base
        </Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center">
        <div className="text-[10px] uppercase tracking-[0.32em] text-text-muted">System anomaly</div>
        <h1 className="mt-2 text-xl font-semibold">This module failed to load</h1>
        <p className="mt-2 text-sm text-text-muted">{error.message}</p>
        <button onClick={reset} className="mt-5 rounded-md glass px-4 py-2 text-sm">Retry</button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Noctra — Founder Intelligence OS" },
      { name: "description", content: "Noctra turns raw ideas into launch-ready systems. An AI Founder Intelligence OS for validation, planning, diagnosis, and launch." },
      { property: "og:title", content: "Noctra — Founder Intelligence OS" },
      { property: "og:description", content: "Signal over noise. Build what survives reality." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
