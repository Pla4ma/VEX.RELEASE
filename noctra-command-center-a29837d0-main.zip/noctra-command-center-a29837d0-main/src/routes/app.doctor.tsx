import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkbench } from "@/components/noctra/ToolWorkbench";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export const Route = createFileRoute("/app/doctor")({
  head: () => ({ meta: [{ title: "Diagnostic Bay — Noctra" }] }),
  component: () => (
    <ToolWorkbench
      tool={TOOL_BY_KEY.doctor}
      placeholder={`Paste a code snippet, repo summary, or error. Noctra diagnoses.`}
      system={`Act as a senior diagnostic engineer. Output: Health score, top issues by severity, repair queue.`}
    />
  ),
});
