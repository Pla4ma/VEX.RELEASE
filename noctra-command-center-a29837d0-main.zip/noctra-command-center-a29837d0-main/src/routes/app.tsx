import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/noctra/AppShell";

export const Route = createFileRoute("/app")({
  component: AppShell,
});
