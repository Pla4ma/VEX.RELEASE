import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkbench } from "@/components/noctra/ToolWorkbench";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export const Route = createFileRoute("/app/swarm")({
  head: () => ({ meta: [{ title: "Market Simulation — Noctra" }] }),
  component: () => (
    <ToolWorkbench
      tool={TOOL_BY_KEY.swarm}
      placeholder={`Describe the offer. Noctra simulates a persona swarm.`}
      system={`Simulate 5 distinct personas reacting to the offer. For each: excitement, objections, willingness to pay.`}
    />
  ),
});
