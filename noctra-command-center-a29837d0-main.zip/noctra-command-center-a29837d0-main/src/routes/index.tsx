import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Radar, ShieldCheck, Rocket, FlaskConical } from "lucide-react";
import { NoctraLogo, NoctraMark } from "@/components/noctra/NoctraLogo";
import { NoctraCompanion } from "@/components/noctra/NoctraCompanion";
import { NoctraBackground } from "@/components/noctra/NoctraBackground";
import { JourneyRail } from "@/components/noctra/JourneyRail";
import { SignalRadar } from "@/components/noctra/SignalRadar";
import { TOOLS } from "@/lib/noctra-tools";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Noctra — Founder Intelligence OS" },
      { name: "description", content: "Noctra is the cinematic AI Founder Intelligence OS. Validate, build, launch, and evolve from one command center." },
      { property: "og:title", content: "Noctra — Founder Intelligence OS" },
      { property: "og:description", content: "Signal over noise. Build what survives reality." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <NoctraBackground variant="hero" />

      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <Link to="/"><NoctraLogo /></Link>
        <nav className="hidden md:flex items-center gap-8 text-xs uppercase tracking-[0.22em] text-text-muted">
          <a href="#system" className="hover:text-foreground">System</a>
          <a href="#flow" className="hover:text-foreground">Journey</a>
          <a href="#core" className="hover:text-foreground">Core</a>
        </nav>
        <Link to="/app" className="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium glass-strong hover:bg-white/[0.06]">
          Enter Command Center <ArrowRight size={14} />
        </Link>
      </header>

      <section className="relative z-10 mx-auto max-w-7xl px-6 pt-12 pb-24 grid lg:grid-cols-[1.1fr_1fr] gap-10 items-center">
        <div>
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 glass rounded-full px-3 py-1 text-[10px] uppercase tracking-[0.28em] text-text-soft">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" /> Founder Intelligence OS
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
            className="mt-6 text-5xl md:text-7xl font-semibold leading-[1.02]">
            Find the signal.<br />
            <span className="text-gradient">Build what survives.</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
            className="mt-5 max-w-xl text-base text-text-soft">
            Noctra is the cinematic AI command center for founders. Stress-test ideas,
            compile reality, validate proof, plan execution, and orchestrate launch — from one cockpit.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
            className="mt-8 flex flex-wrap items-center gap-3">
            <Link to="/app" className="inline-flex items-center gap-2 rounded-lg px-5 py-3 text-sm font-medium text-white"
              style={{ background: "linear-gradient(135deg, var(--noctra-cyan), var(--noctra-violet))",
                boxShadow: "0 24px 60px -20px oklch(0.7 0.22 290 / 0.55)" }}>
              Enter Command Center <ArrowRight size={14} />
            </Link>
            <Link to="/app/idea" className="inline-flex items-center gap-2 rounded-lg glass px-5 py-3 text-sm">
              Run a Signal Scan
            </Link>
          </motion.div>

          <div className="mt-10 grid grid-cols-3 gap-3 max-w-md">
            {[
              { k: "11", l: "Modules" },
              { k: "01", l: "Companion" },
              { k: "∞",  l: "Signal" },
            ].map((s) => (
              <div key={s.l} className="holo rounded-xl p-3 text-center">
                <div className="text-2xl font-semibold text-gradient">{s.k}</div>
                <div className="text-[10px] uppercase tracking-[0.22em] text-text-muted">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative">
          <div className="relative grid place-items-center">
            <NoctraCompanion size={380} state="coaching" label="Noctra Core" message="I'm watching the signal. Open Command Center to see your next move." variant="hero" />
          </div>
          <div className="mt-8 grid grid-cols-2 gap-3">
            {[
              { i: Radar,        l: "Signal scanned",   v: "1,284", a: "var(--noctra-cyan)" },
              { i: ShieldCheck,  l: "Risks surfaced",   v: "37",    a: "var(--noctra-amber)" },
              { i: FlaskConical, l: "Proofs gathered",  v: "212",   a: "var(--noctra-emerald)" },
              { i: Rocket,       l: "Launch readiness", v: "78%",   a: "var(--noctra-violet)" },
            ].map((m) => (
              <div key={m.l} className="holo rounded-xl p-3 flex items-center gap-3">
                <div className="grid place-items-center rounded-lg p-2"
                  style={{ background: `color-mix(in oklab, ${m.a} 18%, transparent)`, border: `1px solid color-mix(in oklab, ${m.a} 35%, transparent)` }}>
                  <m.i size={16} style={{ color: m.a }} />
                </div>
                <div>
                  <div className="text-sm font-semibold">{m.v}</div>
                  <div className="text-[10px] uppercase tracking-[0.22em] text-text-muted">{m.l}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* JOURNEY */}
      <section id="flow" className="relative z-10 mx-auto max-w-7xl px-6 pb-24">
        <div className="text-[10px] uppercase tracking-[0.3em] text-text-muted">Founder journey</div>
        <h2 className="mt-2 text-3xl md:text-5xl font-semibold">From idea to launch — <span className="text-gradient">in one signal.</span></h2>
        <div className="mt-8"><JourneyRail activeIndex={2} /></div>
      </section>

      {/* RADAR */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 pb-24 grid lg:grid-cols-[1fr_1fr] gap-10 items-center">
        <div>
          <div className="text-[10px] uppercase tracking-[0.3em] text-text-muted">System map</div>
          <h3 className="mt-2 text-3xl md:text-4xl font-semibold">A spatial view of <span className="text-gradient">your founder trajectory.</span></h3>
          <p className="mt-4 text-text-soft max-w-md">Every Noctra module feeds a single intelligence radar. See where you stand, what you've validated, and what to run next.</p>
        </div>
        <div className="holo rounded-3xl p-6"><SignalRadar activeIndex={2} /></div>
      </section>

      {/* MODULES */}
      <section id="system" className="relative z-10 mx-auto max-w-7xl px-6 pb-24">
        <div className="text-[10px] uppercase tracking-[0.3em] text-text-muted">Module system</div>
        <h2 className="mt-2 text-3xl md:text-4xl font-semibold">Eleven intelligence modules. <span className="text-gradient">One operating system.</span></h2>
        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {TOOLS.filter((t) => t.key !== "dashboard").map((t) => (
            <motion.div key={t.key}
              initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
              transition={{ duration: 0.4 }}
              className="holo rounded-2xl p-5"
              style={{ borderColor: `color-mix(in oklab, ${t.accent} 28%, transparent)` }}>
              <div className="flex items-start gap-3">
                <div className="grid place-items-center rounded-xl h-11 w-11"
                  style={{
                    background: `linear-gradient(135deg, color-mix(in oklab, ${t.accent} 22%, transparent), color-mix(in oklab, ${t.accent2} 16%, transparent))`,
                    border: `1px solid color-mix(in oklab, ${t.accent} 35%, transparent)`,
                  }}>
                  <t.icon size={17} style={{ color: t.accent }} />
                </div>
                <div>
                  <div className="text-sm font-semibold">{t.diegetic}</div>
                  <div className="text-[10px] uppercase tracking-[0.22em] text-text-muted">{t.group}</div>
                  <div className="text-xs text-text-soft mt-2">{t.long}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CORE / COMPANION */}
      <section id="core" className="relative z-10 mx-auto max-w-7xl px-6 pb-32">
        <div className="glass-strong rounded-3xl p-10 md:p-14 grid md:grid-cols-[1fr_auto] gap-8 items-center overflow-hidden relative">
          <div className="absolute inset-0 -z-10 opacity-60"
            style={{ background: "radial-gradient(800px 220px at 0% 100%, oklch(0.84 0.16 210 / 0.25), transparent 60%), radial-gradient(800px 220px at 100% 0%, oklch(0.7 0.22 290 / 0.25), transparent 60%)" }} />
          <div>
            <div className="text-[10px] uppercase tracking-[0.3em] text-text-muted">Noctra Core</div>
            <h3 className="mt-2 text-3xl md:text-5xl font-semibold">Your AI coach.<br /><span className="text-gradient">Always reading the signal.</span></h3>
            <p className="mt-4 max-w-xl text-text-soft">Noctra Core lives across every module — guiding the next best move, flagging weak signal, and keeping your trajectory sharp.</p>
            <Link to="/app" className="mt-6 inline-flex items-center gap-2 rounded-lg px-5 py-3 text-sm font-medium text-white"
              style={{ background: "linear-gradient(135deg, var(--noctra-cyan), var(--noctra-violet))" }}>
              Open Noctra <ArrowRight size={14} />
            </Link>
          </div>
          <NoctraCompanion size={260} state="thinking" />
        </div>
      </section>

      <footer className="relative z-10 border-t border-white/5 mx-auto max-w-7xl px-6 py-8 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2"><NoctraMark size={20} /><span className="text-xs uppercase tracking-[0.22em] text-text-muted">© Noctra</span></div>
        <div className="text-xs text-text-muted">Signal over noise. Build what survives reality.</div>
      </footer>
    </div>
  );
}
