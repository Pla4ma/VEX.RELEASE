import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { FileText, Filter } from "lucide-react";
import { ToolHeader } from "@/components/noctra/ToolHeader";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";
import { ScoreRing } from "@/components/noctra/Primitives";

export const Route = createFileRoute("/app/reports")({
  head: () => ({ meta: [{ title: "Intelligence Archive — Noctra" }] }),
  component: ReportsPage,
});

const SAMPLE = [
  { id: "1", title: "Signal Scan: AI for indie devs", verdict: "Strong",    score: 84, color: "var(--noctra-emerald)", body: "## Verdict\nSharp founder-market fit. Distribution moat unclear.\n\n## Strengths\n- Fast user acquisition path via dev twitter\n- Clear pain frequency (weekly)\n- Founder is target user\n\n## Risks\n- Crowded category\n- Monetization through prosumer pricing only\n\n## Next\nRun a Validation Lab cycle on cold outbound." },
  { id: "2", title: "Reality Scan: market timing window", verdict: "Caution", score: 52, color: "var(--noctra-amber)",   body: "## Pressure\nTiming risk in 6-9 month horizon.\n\n## Blind spots\n- LLM model commoditization\n- Distribution dependency on a single channel\n\n## Recommend\nRe-run Reality Scanner after pilot." },
  { id: "3", title: "Validation: cold outbound v3",      verdict: "Validated",score: 78, color: "var(--noctra-cyan)",     body: "## Evidence\nReply rate 4.2% on 240 emails. Strong wedge.\n\n## Move\nProgress to Launch Control." },
];

function ReportsPage() {
  const tool = TOOL_BY_KEY.reports;
  const [selected, setSelected] = useState(SAMPLE[0]);
  return (
    <div className="space-y-6">
      <ToolHeader icon={tool.icon} accent={tool.accent} accent2={tool.accent2}
        label={tool.label} diegetic={tool.diegetic} description="All intelligence briefings produced across modules." />

      <div className="grid lg:grid-cols-[340px_1fr] gap-6">
        <div className="holo rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3 px-1">
            <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Briefings</div>
            <Filter size={14} className="text-text-muted" />
          </div>
          <ul className="space-y-2">
            {SAMPLE.map((b) => {
              const active = b.id === selected.id;
              return (
                <li key={b.id}>
                  <button
                    onClick={() => setSelected(b)}
                    className={`w-full text-left rounded-xl px-3 py-3 transition-colors border ${active ? "bg-white/[0.05]" : "hover:bg-white/[0.03] border-transparent"}`}
                    style={active ? { borderColor: `color-mix(in oklab, ${b.color} 45%, transparent)` } : undefined}
                  >
                    <div className="flex items-start gap-2">
                      <FileText size={14} className="mt-0.5 text-text-muted" />
                      <div className="min-w-0 flex-1">
                        <div className="text-sm truncate">{b.title}</div>
                        <div className="text-[10px] uppercase tracking-[0.22em] text-text-muted mt-0.5">Score {b.score}</div>
                      </div>
                      <span className="text-[10px] uppercase tracking-[0.18em] px-2 py-0.5 rounded-full"
                        style={{ background: `color-mix(in oklab, ${b.color} 18%, transparent)`, color: b.color }}>
                        {b.verdict}
                      </span>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        <motion.div key={selected.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
          <div className="holo rounded-2xl overflow-hidden"
            style={{ borderColor: `color-mix(in oklab, ${selected.color} 40%, transparent)` }}>
            <div className="px-5 pt-5 pb-4 border-b border-white/5 relative">
              <div className="absolute inset-x-0 top-0 h-px"
                style={{ background: `linear-gradient(90deg, transparent, ${selected.color}, transparent)` }} />
              <div className="flex items-start gap-4">
                <div className="min-w-0 flex-1">
                  <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Intelligence briefing</div>
                  <h2 className="text-xl font-semibold mt-1">{selected.title}</h2>
                  <div className="text-xs text-text-muted">Compiled by Noctra Core</div>
                </div>
                <ScoreRing value={selected.score} size={64} accent={selected.color} label="Signal" />
                <span className="text-[10px] uppercase tracking-[0.2em] px-3 py-1 rounded-full self-center"
                  style={{ background: `color-mix(in oklab, ${selected.color} 22%, transparent)`, color: selected.color }}>
                  {selected.verdict}
                </span>
              </div>
            </div>
            <div className="px-5 py-5">
              <pre className="whitespace-pre-wrap text-sm text-text-soft font-sans leading-relaxed">{selected.body}</pre>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
