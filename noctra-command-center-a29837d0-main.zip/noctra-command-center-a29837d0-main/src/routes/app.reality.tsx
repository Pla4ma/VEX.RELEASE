import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkbench } from "@/components/noctra/ToolWorkbench";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";

export const Route = createFileRoute("/app/reality")({
  head: () => ({ meta: [{ title: "Reality Scanner — Noctra" }] }),
  component: () => (
    <ToolWorkbench
      tool={TOOL_BY_KEY.reality}
      placeholder={`Paste assumptions. Noctra compiles risks, blind spots, and feasibility.`}
      system={`You are a brutal reality compiler. Output: Feasibility (1-10), key risks, blind spots, decisive next move.`}
    />
  ),
});
