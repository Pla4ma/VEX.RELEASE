import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ToolHeader } from "@/components/noctra/ToolHeader";
import { TOOL_BY_KEY } from "@/lib/noctra-tools";
import { NoctraCompanion } from "@/components/noctra/NoctraCompanion";
import { Flag, Zap, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/app/tasks")({
  head: () => ({ meta: [{ title: "Execution Queue — Noctra" }] }),
  component: TasksPage,
});

const COLUMNS = [
  { name: "Backlog",   icon: Flag,         color: "var(--noctra-text-muted)", items: [
    { t: "Define wedge persona", p: "high" },
    { t: "Draft launch story",   p: "med" },
    { t: "Audit landing copy",   p: "low" },
  ] },
  { name: "In motion", icon: Zap,          color: "var(--noctra-cyan)",       items: [
    { t: "Run Signal Scanner v2", p: "high" },
    { t: "Cold outreach batch 3", p: "med" },
  ] },
  { name: "Validated", icon: CheckCircle2, color: "var(--noctra-emerald)",    items: [
    { t: "Pricing test",   p: "med" },
    { t: "Onboarding loop",p: "low" },
  ] },
];

const PRI: Record<string, string> = {
  high: "var(--noctra-rose)", med: "var(--noctra-amber)", low: "var(--noctra-cyan)",
};

function TasksPage() {
  const tool = TOOL_BY_KEY.tasks;
  return (
    <div className="space-y-6">
      <ToolHeader icon={tool.icon} accent={tool.accent} accent2={tool.accent2}
        label={tool.label} diegetic={tool.diegetic} description="Mission queue compiled from your validation work." />

      <div className="holo rounded-2xl p-5 grid md:grid-cols-[1fr_auto] gap-4 items-center"
        style={{ borderColor: `color-mix(in oklab, ${tool.accent} 30%, transparent)` }}>
        <div>
          <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">Sprint pulse</div>
          <h2 className="text-xl font-semibold mt-1">7 missions active · 2 validated this week</h2>
          <div className="mt-3 h-1.5 rounded-full bg-white/5 overflow-hidden max-w-md">
            <motion.div initial={{ width: 0 }} animate={{ width: "62%" }} transition={{ duration: 1.2 }}
              className="h-full" style={{ background: `linear-gradient(90deg, ${tool.accent}, ${tool.accent2})` }} />
          </div>
        </div>
        <NoctraCompanion size={90} variant="compact" state="coaching" />
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {COLUMNS.map((col, i) => {
          const Icon = col.icon;
          return (
            <div key={col.name} className="holo rounded-2xl p-4"
              style={{ borderColor: `color-mix(in oklab, ${col.color} 30%, transparent)` }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Icon size={14} style={{ color: col.color }} />
                  <div className="text-[10px] uppercase tracking-[0.28em]" style={{ color: col.color }}>{col.name}</div>
                </div>
                <span className="text-xs text-text-muted">{col.items.length}</span>
              </div>
              <ul className="space-y-2">
                {col.items.map((t, j) => (
                  <motion.li key={t.t} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 + j * 0.04 }}
                    whileHover={{ y: -2 }}
                    className="rounded-lg border border-white/5 bg-black/20 p-3 text-sm hover:bg-black/30 relative overflow-hidden">
                    <div className="absolute left-0 top-0 bottom-0 w-0.5" style={{ background: PRI[t.p] }} />
                    <div className="pl-2 flex items-center justify-between">
                      <span>{t.t}</span>
                      <span className="text-[10px] uppercase tracking-[0.2em]" style={{ color: PRI[t.p] }}>{t.p}</span>
                    </div>
                  </motion.li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}
