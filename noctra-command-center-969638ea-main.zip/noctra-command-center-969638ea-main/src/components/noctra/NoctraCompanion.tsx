import { motion, useReducedMotion } from "framer-motion";
import coachIdle from "@/assets/companion/noctra-coach-idle.png";
import coachAnalyzing from "@/assets/companion/noctra-coach-analyzing.png";
import coachSuccess from "@/assets/companion/noctra-coach-success.png";

export type CompanionState =
  | "idle" | "listening" | "thinking" | "analyzing"
  | "coaching" | "warning" | "success" | "error"
  | "launching" | "scanning" | "celebrating";

export type CompanionVariant = "hero" | "dashboard" | "compact" | "tool";

const STATE_TONE: Record<CompanionState, { primary: string; secondary: string; speed: number; pulse: number; asset: string }> = {
  idle:        { primary: "var(--noctra-cyan)",    secondary: "var(--noctra-violet)",  speed: 22, pulse: 3.0, asset: coachIdle },
  listening:   { primary: "var(--noctra-cyan)",    secondary: "var(--noctra-violet)",  speed: 16, pulse: 2.4, asset: coachIdle },
  thinking:    { primary: "var(--noctra-magenta)", secondary: "var(--noctra-violet)",  speed: 10, pulse: 1.8, asset: coachAnalyzing },
  analyzing:   { primary: "var(--noctra-violet)",  secondary: "var(--noctra-cyan)",    speed: 7,  pulse: 1.2, asset: coachAnalyzing },
  coaching:    { primary: "var(--noctra-cyan)",    secondary: "var(--noctra-emerald)", speed: 18, pulse: 2.4, asset: coachIdle },
  warning:     { primary: "var(--noctra-amber)",   secondary: "var(--noctra-rose)",    speed: 12, pulse: 1.6, asset: coachAnalyzing },
  success:     { primary: "var(--noctra-emerald)", secondary: "var(--noctra-gold)",    speed: 24, pulse: 2.6, asset: coachSuccess },
  error:       { primary: "var(--noctra-rose)",    secondary: "var(--noctra-amber)",   speed: 10, pulse: 1.4, asset: coachAnalyzing },
  launching:   { primary: "var(--noctra-amber)",   secondary: "var(--noctra-cyan)",    speed: 6,  pulse: 1.0, asset: coachSuccess },
  scanning:    { primary: "var(--noctra-cyan)",    secondary: "var(--noctra-violet)",  speed: 8,  pulse: 1.2, asset: coachAnalyzing },
  celebrating: { primary: "var(--noctra-gold)",    secondary: "var(--noctra-magenta)", speed: 18, pulse: 1.8, asset: coachSuccess },
};

export function NoctraCompanion({
  state = "idle",
  size = 220,
  label,
  variant = "dashboard",
  message,
}: {
  state?: CompanionState;
  size?: number;
  label?: string;
  variant?: CompanionVariant;
  message?: string;
}) {
  const reduced = useReducedMotion();
  const tone = STATE_TONE[state];
  const { primary, secondary, asset } = tone;
  const isScanning = state === "analyzing" || state === "scanning" || state === "thinking";

  return (
    <div className="relative inline-flex flex-col items-center gap-3" style={{ width: size }}>
      <div className="relative" style={{ width: size, height: size }}>
        {/* outer aura */}
        <motion.div
          className="absolute inset-0 rounded-full blur-3xl"
          style={{
            background: `radial-gradient(circle, color-mix(in oklab, ${primary} 55%, transparent), transparent 65%)`,
          }}
          animate={reduced ? {} : { opacity: [0.45, 0.75, 0.45], scale: [0.95, 1.05, 0.95] }}
          transition={{ duration: tone.pulse * 2, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* outer rotating ring with tick marks */}
        <motion.svg
          className="absolute inset-0 pointer-events-none"
          viewBox="0 0 200 200"
          animate={reduced ? {} : { rotate: 360 }}
          transition={{ duration: tone.speed, ease: "linear", repeat: Infinity }}
        >
          <circle cx="100" cy="100" r="96" fill="none"
            stroke={`color-mix(in oklab, ${primary} 45%, transparent)`} strokeWidth="0.5" />
          {Array.from({ length: 60 }).map((_, i) => {
            const a = (i * 6 * Math.PI) / 180;
            const inner = i % 5 === 0 ? 86 : 92;
            return (
              <line key={i}
                x1={100 + Math.cos(a) * inner} y1={100 + Math.sin(a) * inner}
                x2={100 + Math.cos(a) * 96} y2={100 + Math.sin(a) * 96}
                stroke={`color-mix(in oklab, ${primary} 55%, transparent)`} strokeWidth="0.6" />
            );
          })}
        </motion.svg>

        {/* mid dashed counter ring */}
        <motion.div
          className="absolute rounded-full pointer-events-none"
          style={{
            inset: size * 0.08,
            border: `1px dashed color-mix(in oklab, ${secondary} 50%, transparent)`,
          }}
          animate={reduced ? {} : { rotate: -360 }}
          transition={{ duration: tone.speed * 1.6, ease: "linear", repeat: Infinity }}
        />

        {/* coach asset */}
        <motion.div
          className="absolute overflow-hidden rounded-full"
          style={{
            inset: size * 0.06,
            background: `radial-gradient(60% 60% at 50% 40%, color-mix(in oklab, ${primary} 22%, transparent), transparent 70%)`,
          }}
          animate={reduced ? {} : { y: [0, -5, 0] }}
          transition={{ duration: 6, ease: "easeInOut", repeat: Infinity }}
        >
          <motion.img
            src={asset}
            alt="Noctra AI coach"
            className="absolute inset-0 h-full w-full object-contain object-center select-none pointer-events-none"
            style={{
              filter: `drop-shadow(0 12px 40px color-mix(in oklab, ${primary} 60%, transparent))`,
            }}
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            draggable={false}
          />
          {/* color overlay tint by state */}
          <div
            className="absolute inset-0 mix-blend-color opacity-40 pointer-events-none"
            style={{ background: `linear-gradient(160deg, ${primary}, transparent 60%, ${secondary})` }}
          />
          {/* visor scan beam */}
          {isScanning && !reduced && (
            <motion.div
              className="absolute left-0 right-0 h-[14%] pointer-events-none"
              style={{
                background: `linear-gradient(180deg, transparent, color-mix(in oklab, ${primary} 75%, transparent), transparent)`,
                filter: "blur(4px)",
                mixBlendMode: "screen",
              }}
              animate={{ top: ["10%", "85%", "10%"] }}
              transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
            />
          )}
        </motion.div>

        {/* orbiting nodes */}
        {[0, 120, 240].map((deg, i) => (
          <motion.div
            key={i}
            className="absolute inset-0 pointer-events-none"
            animate={reduced ? {} : { rotate: 360 }}
            transition={{ duration: tone.speed * 0.7, ease: "linear", repeat: Infinity, delay: i * 0.3 }}
            style={{ transformOrigin: "50% 50%", rotate: `${deg}deg` }}
          >
            <div
              className="absolute h-1.5 w-1.5 rounded-full"
              style={{
                top: 2, left: "50%",
                background: i % 2 ? secondary : primary,
                boxShadow: `0 0 12px ${i % 2 ? secondary : primary}`,
              }}
            />
          </motion.div>
        ))}

        {/* holographic base */}
        {variant !== "compact" && (
          <div
            className="absolute left-1/2 -translate-x-1/2 rounded-[50%] pointer-events-none"
            style={{
              bottom: -size * 0.04,
              width: size * 0.74,
              height: size * 0.07,
              background: `radial-gradient(50% 100% at 50% 0%, color-mix(in oklab, ${primary} 60%, transparent), transparent 70%)`,
              filter: "blur(3px)",
            }}
          />
        )}
      </div>

      {label && (
        <div className="text-[10px] uppercase tracking-[0.28em] text-text-muted">{label}</div>
      )}

      {message && variant !== "compact" && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-xl px-3 py-2 text-xs text-text-soft max-w-[260px] text-center"
          style={{ borderColor: `color-mix(in oklab, ${primary} 35%, transparent)` }}
        >
          {message}
        </motion.div>
      )}
    </div>
  );
}

export function CompanionCoach({
  state = "coaching",
  title,
  message,
  cta,
  size = 200,
}: {
  state?: CompanionState; title?: string; message: string;
  cta?: { label: string; onClick?: () => void; href?: string };
  size?: number;
}) {
  const tone = STATE_TONE[state];
  return (
    <div className="relative grid sm:grid-cols-[auto_1fr] gap-5 items-center">
      <NoctraCompanion state={state} size={size} variant="dashboard" />
      <div className="glass rounded-2xl p-4 relative"
        style={{ borderColor: `color-mix(in oklab, ${tone.primary} 35%, transparent)` }}>
        <div className="text-[10px] uppercase tracking-[0.28em]" style={{ color: tone.primary }}>
          Noctra Core · {state}
        </div>
        {title && <div className="mt-1 font-semibold text-foreground">{title}</div>}
        <div className="mt-1 text-sm text-text-soft">{message}</div>
        {cta && (
          <a
            href={cta.href}
            onClick={cta.onClick}
            className="mt-3 inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium text-white"
            style={{ background: `linear-gradient(135deg, ${tone.primary}, ${tone.secondary})` }}
          >
            {cta.label}
          </a>
        )}
      </div>
    </div>
  );
}
